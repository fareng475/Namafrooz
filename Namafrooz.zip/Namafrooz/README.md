# Namafrooz (نمافروز)
Video player for Android: folders with thumbnails and progress, continue watching, search,
hold-right = fast speed, double-tap skip, swipe for volume/brightness, external subtitles,
Persian/English language, light/dark theme and accent colors.

Build: push to GitHub -> Actions -> "Build APK" -> download artifact. Or open in Android Studio and Run.


v1.2: Persian loading screen, double-tap-only skipping, settings menu (speed, audio/subtitle track, add subtitle file),
subtitle and audio sync buttons (top right of the player).

v1.3: fixed settings being reset after changing the app language; resume playback is on by default.

v1.4: folder/video list size settings (small, medium, large); opening a folder always starts at its top.

v1.5: rotate button, pinch zoom (with toggle in settings), folder list shows only video counts, 1% volume swipe with speaker icon.

v1.6: offline AI English subtitles (Whisper base.en + Silero VAD via sherpa-onnx), in the player settings menu.
