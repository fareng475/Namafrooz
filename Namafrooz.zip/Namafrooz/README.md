# Namafrooz (نمافروز)
Video player for Android: folders with thumbnails and progress, continue watching, search,
hold-right = fast speed, double-tap skip, swipe for volume/brightness, external subtitles,
Persian/English language, light/dark theme and accent colors.

Build: push to GitHub -> Actions -> "Build APK" -> download artifact. Or open in Android Studio and Run.


v1.2: Persian loading screen, double-tap-only skipping, settings menu (speed, audio/subtitle track, add subtitle file),
subtitle and audio sync buttons (top right of the player).
