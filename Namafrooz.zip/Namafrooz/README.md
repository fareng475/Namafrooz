# Namafrooz (نمافروز)
Video player for Android: folders with thumbnails and progress, continue watching, search,
hold-right = fast speed, double-tap skip, swipe for volume/brightness, external subtitles,
Persian/English language, light/dark theme and accent colors.

Build: push to GitHub -> Actions -> "Build APK" -> download artifact. Or open in Android Studio and Run.


v1.2: Persian loading screen, double-tap-only skipping, settings menu (speed, audio/subtitle track, add subtitle file),
subtitle and audio sync buttons (top right of the player).

v1.3: fixed settings being reset after changing the app language; resume playback is on by default.

v1.4: folder/video list size settings (small, medium, large); opening a folder always starts at its top.

v1.5: rotate button, pinch zoom (with toggle in settings), folder list shows only video counts, 1% volume swipe with speaker icon.

v1.6: offline AI English subtitles (Whisper base.en + Silero VAD via sherpa-onnx), in the player settings menu.

v1.6 also: target/compile SDK 36 (AGP 8.9.1, Gradle 8.11.1), edge-to-edge insets, lock screen, picture-in-picture, favorites (long-press a video), Windows-1256 subtitle fix.

v1.6.1: AI subtitle feature removed (it crashed); app is small again.

v1.7: translucent side settings panel in the player (tracks, speed, picture fit, quick switches) and full subtitle look settings (size, color, background, position, weight).

v1.8: audio and subtitle sync moved into the settings panel (separate sections); in-app translucent file browser for adding subtitle files (needs all-files access).

v1.9: compact audio/subtitle sections with big sync buttons, add external audio file, file browser starts at the whole storage with shortcuts and an all-files switch.

v2.0: subtitles now use our own engine (SRT/VTT/ASS, Persian encodings, auto-load of same-name files, remembered per video) with clear error messages.

v2.1: swipe left/right to seek, speed section at the top of the panel (+3x), subtitle size slider and same-size subtitles in portrait/landscape (kept inside the video frame), error report page in settings.

v2.2: subtitle can use the screen width next to a narrow vertical video, buttons to remove an added audio file / subtitle file, clearer audio track names (codec, channels).

v2.3: play videos from a link (HTTP/HTTPS, HLS, DASH) with the new gold symbol next to settings; the folder of the last watched video has a soft gold name.
