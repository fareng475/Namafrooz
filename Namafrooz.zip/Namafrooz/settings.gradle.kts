import org.gradle.util.GradleVersion

pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
    plugins {
        // Gradle 8.11.1 or newer -> newest Android plugin (needed for SDK 36).
        // Older Gradle (the workflow still says 8.7) -> the previous plugin, so the build never breaks.
        val newGradle = GradleVersion.current() >= GradleVersion.version("8.11.1")
        id("com.android.application") version (if (newGradle) "8.9.1" else "8.5.2")
    }
}
dependencyResolutionManagement { repositories { google(); mavenCentral() } }
rootProject.name = "Namafrooz"
include(":app")
