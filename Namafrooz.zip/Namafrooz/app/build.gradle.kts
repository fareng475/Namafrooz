import org.gradle.util.GradleVersion

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// SDK 36 needs Gradle 8.11.1+; with older Gradle we keep SDK 34 so the build still works.
val sdkLevel = if (GradleVersion.current() >= GradleVersion.version("8.11.1")) 36 else 34

android {
    namespace = "com.namafrooz.player"
    compileSdk = sdkLevel
    defaultConfig {
        applicationId = "com.namafrooz.player"
        minSdk = 24
        targetSdk = sdkLevel
        versionCode = 12
        versionName = "2.0"
    }
    signingConfigs {
        // Fixed key so every GitHub build is signed the same way and can update the installed app.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
