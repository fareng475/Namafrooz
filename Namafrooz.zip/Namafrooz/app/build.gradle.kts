plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
// ---- offline AI (speech recognition) files, downloaded once while building ----
fun fetchFile(dest: File, vararg urls: String) {
    if (dest.exists() && dest.length() > 1024) return
    dest.parentFile.mkdirs()
    var last: Exception? = null
    for (u in urls) {
        try {
            val tmp = File(dest.path + ".part")
            java.net.URL(u).openStream().use { input -> tmp.outputStream().use { out -> input.copyTo(out) } }
            if (tmp.length() < 1024) throw GradleException("empty download")
            tmp.renameTo(dest)
            return
        } catch (e: Exception) {
            last = e
        }
    }
    throw GradleException("Could not download " + dest.name + ": " + last?.message)
}

val sherpaVersion = "1.10.41"
val aiAssets = file("src/main/assets/ai")
fetchFile(
    file("libs/sherpa-onnx-$sherpaVersion.aar"),
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/v$sherpaVersion/sherpa-onnx-$sherpaVersion.aar",
    "https://huggingface.co/csukuangfj/sherpa-onnx-libs/resolve/main/android/aar/sherpa-onnx-$sherpaVersion.aar"
)
fetchFile(
    File(aiAssets, "silero_vad.onnx"),
    "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx"
)
val whisperRepo = "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-base.en/resolve/main"
fetchFile(File(aiAssets, "whisper-encoder.onnx"), "$whisperRepo/base.en-encoder.int8.onnx")
fetchFile(File(aiAssets, "whisper-decoder.onnx"), "$whisperRepo/base.en-decoder.int8.onnx")
fetchFile(File(aiAssets, "whisper-tokens.txt"), "$whisperRepo/base.en-tokens.txt")

android {
    namespace = "com.namafrooz.player"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.namafrooz.player"
        minSdk = 24
        targetSdk = 34
        versionCode = 7
        versionName = "1.6"
    }
    signingConfigs {
        // Fixed key so every GitHub build is signed the same way and can update the installed app.
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    androidResources {
        noCompress += listOf("onnx")
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(files("libs/sherpa-onnx-$sherpaVersion.aar"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("com.github.bumptech.glide:glide:4.16.0")
}
