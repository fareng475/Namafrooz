package com.namafrooz.player

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var adapter: VideoAdapter
    private lateinit var tvSub: TextView
    private lateinit var emptyBox: View
    private lateinit var tvEmpty: TextView
    private var folders: List<Folder> = emptyList()
    private var current: Folder? = null

    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) load() else showEmpty(getString(R.string.perm_needed), true)
    }
    private val openLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) playSingle(uri)
    }
    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            current = null
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_main)
        tvSub = findViewById(R.id.tvSub)
        emptyBox = findViewById(R.id.emptyBox)
        tvEmpty = findViewById(R.id.tvEmpty)

        adapter = VideoAdapter(
            onFolder = { current = it; render() },
            onVideo = { list, index ->
                PlaybackQueue.items = list
                PlaybackQueue.start = index
                startActivity(Intent(this, PlayerActivity::class.java))
            }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        findViewById<MaterialButton>(R.id.btnOpen).setOnClickListener { openLauncher.launch(arrayOf("video/*")) }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<MaterialButton>(R.id.btnGrant).setOnClickListener { permLauncher.launch(perm) }
        onBackPressedDispatcher.addCallback(this, backCb)

        if (!granted()) permLauncher.launch(perm)
    }

    override fun onResume() {
        super.onResume()
        if (granted()) load()
    }

    private fun granted() = ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun load() {
        Thread {
            val result = MediaRepo.load(this)
            runOnUiThread {
                folders = result
                current = current?.let { c -> result.find { it.id == c.id } }
                render()
            }
        }.start()
    }

    private fun render() {
        backCb.isEnabled = current != null
        val c = current
        tvSub.text = c?.name ?: getString(R.string.subtitle_folders)
        val rows: List<Any> = c?.videos ?: folders
        adapter.submit(rows)
        if (rows.isEmpty()) showEmpty(getString(R.string.no_videos), false) else emptyBox.visibility = View.GONE
    }

    private fun showEmpty(text: String, showGrant: Boolean) {
        tvEmpty.text = text
        findViewById<View>(R.id.btnGrant).visibility = if (showGrant) View.VISIBLE else View.GONE
        emptyBox.visibility = View.VISIBLE
    }

    private fun playSingle(uri: Uri) {
        var name = uri.lastPathSegment ?: "video"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) name = c.getString(i)
        }
        PlaybackQueue.items = listOf(Video(0, uri, name, 0, "", 0))
        PlaybackQueue.start = 0
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun showSettings() {
        val seekOpts = listOf(5, 10, 15, 30)
        val speedOpts = listOf(1.5f, 2f, 2.5f, 3f)
        val items = arrayOf(
            "${getString(R.string.skip_label)}: ${Prefs.seekSeconds}",
            "${getString(R.string.speed_label)}: ${Prefs.holdSpeed}x",
            "${getString(R.string.resume_label)}: " + getString(if (Prefs.resume) R.string.on else R.string.off)
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.settings)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> Prefs.seekSeconds = seekOpts[(seekOpts.indexOf(Prefs.seekSeconds) + 1) % seekOpts.size]
                    1 -> Prefs.holdSpeed = speedOpts[(speedOpts.indexOf(Prefs.holdSpeed) + 1) % speedOpts.size]
                    2 -> Prefs.resume = !Prefs.resume
                }
                showSettings()
            }
            .setPositiveButton(R.string.close, null)
            .show()
    }
}
