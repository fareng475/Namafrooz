package com.namafrooz.player

import android.view.WindowManager
import android.widget.LinearLayout
import android.text.InputType
import android.net.Uri
import android.content.Context
import android.content.ClipboardManager
import android.widget.Toast
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : BaseActivity() {

    private lateinit var adapter: VideoAdapter
    private lateinit var tvSub: TextView
    private lateinit var emptyBox: View
    private lateinit var tvEmpty: TextView
    private lateinit var etSearch: EditText
    private lateinit var contCard: View
    private lateinit var tvContName: TextView
    private lateinit var contProg: ProgressBar

    private var folders: List<Folder> = emptyList()
    private var current: Folder? = null
    private var query = ""
    private lateinit var lm: LinearLayoutManager
    private var lockedMode = false   // true = this screen shows only the locked folders
    private var toPlayer = false
    private var shownId: Long? = null            // folder currently shown (null = folder list)
    private var folderListState: Parcelable? = null // scroll position of the folder list

    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) load() else showEmpty(getString(R.string.perm_needed), true)
    }
    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            current = null
            render()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        lockedMode = intent.getBooleanExtra(EXTRA_LOCKED, false)
        if (lockedMode) {
            // no screenshots and no preview in the recent-apps list while locked folders are open
            window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
            for (id in intArrayOf(R.id.btnOnline, R.id.btnLock, R.id.btnSettings)) {
                findViewById<View>(id).visibility = View.GONE
            }
        }
        tvSub = findViewById(R.id.tvSub)
        emptyBox = findViewById(R.id.emptyBox)
        tvEmpty = findViewById(R.id.tvEmpty)
        etSearch = findViewById(R.id.etSearch)
        contCard = findViewById(R.id.contCard)
        tvContName = findViewById(R.id.tvContName)
        contProg = findViewById(R.id.contProg)

        adapter = VideoAdapter(
            onFolder = { current = it; render() },
            onFolderLong = { if (it.id != FAV_ID) folderMenu(it) },
            onVideo = { list, index -> play(list, index) },
            onVideoLong = { toggleFav(it) }
        )
        findViewById<RecyclerView>(R.id.list).apply {
            lm = LinearLayoutManager(this@MainActivity)
            layoutManager = lm
            adapter = this@MainActivity.adapter
        }
        findViewById<ImageButton>(R.id.btnOnline).setOnClickListener { showOnlineDialog() }
        findViewById<ImageButton>(R.id.btnLock).setOnClickListener {
            FolderLock.enter(this) {
                startActivity(Intent(this, MainActivity::class.java).putExtra(EXTRA_LOCKED, true))
            }
        }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<MaterialButton>(R.id.btnGrant).setOnClickListener { permLauncher.launch(perm) }
        etSearch.doAfterTextChanged {
            query = it?.toString().orEmpty().trim()
            render()
        }
        onBackPressedDispatcher.addCallback(this, backCb)

        if (!granted()) permLauncher.launch(perm)
    }

    override fun onStop() {
        super.onStop()
        // leaving the app closes the locked area; the PIN is asked again next time
        if (lockedMode && !toPlayer && !isChangingConfigurations) finish()
    }

    override fun onResume() {
        super.onResume()
        toPlayer = false
        if (granted()) load()
    }

    private fun granted() = ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED

    private fun load() {
        Thread {
            val result = MediaRepo.load(this)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                folders = result
                current = current?.let { c -> result.find { it.id == c.id } }
                render()
            }
        }.start()
    }

    private val FAV_ID = -777L

    private fun favoritesFolder(): Folder? {
        val fav = Prefs.favorites
        if (fav.isEmpty()) return null
        val open = folders.filter { it.id.toString() !in Prefs.locked }
        val vids = open.flatMap { it.videos }.filter { it.uri.toString() in fav }
        return if (vids.isEmpty()) null else Folder(FAV_ID, getString(R.string.favorites_folder), vids)
    }

    private fun toggleFav(v: Video) {
        val on = Prefs.toggleFavorite(v.uri.toString())
        Toast.makeText(this, if (on) R.string.fav_added else R.string.fav_removed, Toast.LENGTH_SHORT).show()
        render()
    }

    private fun visibleFolders(): List<Folder> {
        val hidden = Prefs.hidden
        val locked = Prefs.locked
        val list = if (lockedMode) {
            folders.filter { it.id.toString() in locked }
        } else {
            folders.filter { it.id.toString() !in hidden && it.id.toString() !in locked }
        }
        val sorted = if (Prefs.sort == "count") list.sortedByDescending { it.videos.size } else list
        if (lockedMode) return sorted
        val fav = favoritesFolder()
        return if (fav != null) listOf(fav) + sorted else sorted
    }

    private fun render() {
        if (current?.id == FAV_ID) current = favoritesFolder()
        backCb.isEnabled = current != null
        val c = current
        tvSub.text = c?.name ?: getString(if (lockedMode) R.string.locked_title else R.string.subtitle_folders)
        val q = query.lowercase()
        val rows: List<Any> = if (c != null) {
            c.videos.filter { q.isEmpty() || it.name.lowercase().contains(q) }
        } else {
            visibleFolders().filter { q.isEmpty() || it.name.lowercase().contains(q) }
        }
        val newId = c?.id
        val switched = newId != shownId
        if (switched && shownId == null) folderListState = lm.onSaveInstanceState()
        adapter.submit(rows)
        if (switched) {
            if (newId == null) {
                // back to the folder list: return to where the user was
                folderListState?.let { lm.onRestoreInstanceState(it) }
            } else {
                // a folder was opened: always start at its first video
                lm.scrollToPositionWithOffset(0, 0)
            }
        }
        shownId = newId
        updateContinue()
        if (rows.isEmpty()) {
            showEmpty(
                getString(
                    if (q.isNotEmpty()) R.string.no_results
                    else if (lockedMode && c == null) R.string.locked_empty
                    else R.string.no_videos
                ),
                false
            )
        } else {
            emptyBox.visibility = View.GONE
        }
    }

    /** Asks for a video link and plays it with the normal player. */
    private fun showOnlineDialog() {
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val input = EditText(this)
        input.hint = getString(R.string.online_hint)
        input.setSingleLine()
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.textDirection = View.TEXT_DIRECTION_LTR
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val paste = TextView(this)
        paste.text = getString(R.string.online_paste)
        paste.setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        paste.setTextColor(0xFFE0B04A.toInt())
        paste.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.text?.toString()
            if (!text.isNullOrBlank()) input.setText(text.trim())
        }
        row.addView(paste)
        box.addView(row)

        val recent = Prefs.recentLinks.take(5)
        if (recent.isNotEmpty()) {
            val title = TextView(this)
            title.text = getString(R.string.online_recent)
            title.textSize = 12f
            title.setPadding(0, pad / 2, 0, pad / 4)
            box.addView(title)
            for (u in recent) {
                val t = TextView(this)
                t.text = u
                t.textSize = 13f
                t.maxLines = 1
                t.ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                t.textDirection = View.TEXT_DIRECTION_LTR
                t.setPadding(0, pad / 4, 0, pad / 4)
                t.setOnClickListener { input.setText(u) }
                box.addView(t)
            }
        }
        val b = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.online_title)
            .setView(box)
            .setPositiveButton(R.string.online_play) { _, _ -> playLink(input.text.toString()) }
            .setNegativeButton(R.string.cancel, null)
        if (recent.isNotEmpty()) b.setNeutralButton(R.string.online_clear) { _, _ -> Prefs.clearRecentLinks() }
        b.show()
    }

    private fun playLink(raw: String) {
        val url = raw.trim()
        if (!(url.startsWith("http://", true) || url.startsWith("https://", true))) {
            Toast.makeText(this, R.string.online_invalid, Toast.LENGTH_LONG).show()
            return
        }
        Prefs.addRecentLink(url)
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .setAction(Intent.ACTION_VIEW)
                .setData(Uri.parse(url))
        )
    }

    private fun updateContinue() {
        if (lockedMode) {
            contCard.visibility = View.GONE
            return
        }
        val key = Prefs.lastKey
        val hit: Pair<Folder, Video>? =
            if (current == null && query.isEmpty() && key.isNotEmpty()) {
                folders.filter { it.id.toString() !in Prefs.locked }.firstNotNullOfOrNull { f ->
                    f.videos.firstOrNull { it.uri.toString() == key }?.let { v -> f to v }
                }
            } else null
        val pct = Prefs.percent(key)
        if (hit == null || pct < 2 || pct >= 95) {
            contCard.visibility = View.GONE
            return
        }
        val (folder, video) = hit
        contCard.visibility = View.VISIBLE
        tvContName.text = video.name
        contProg.progress = pct
        contCard.setOnClickListener { play(folder.videos, folder.videos.indexOf(video)) }
    }

    private fun showEmpty(text: String, showGrant: Boolean) {
        tvEmpty.text = text
        findViewById<View>(R.id.btnGrant).visibility = if (showGrant) View.VISIBLE else View.GONE
        emptyBox.visibility = View.VISIBLE
    }

    private fun play(list: List<Video>, index: Int) {
        toPlayer = true
        PlaybackQueue.items = list
        PlaybackQueue.start = index.coerceAtLeast(0)
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    /** Long press on a folder: hide it, lock it, or (in the locked area) unlock it. */
    private fun folderMenu(f: Folder) {
        val b = MaterialAlertDialogBuilder(this).setTitle(f.name)
        if (lockedMode) {
            b.setItems(arrayOf(getString(R.string.unlock_folder))) { _, _ ->
                Prefs.locked = Prefs.locked - f.id.toString()
                render()
            }
        } else {
            b.setItems(arrayOf(getString(R.string.hide), getString(R.string.lock_folder))) { _, which ->
                if (which == 0) confirmHide(f) else lockFolder(f)
            }
        }
        b.show()
    }

    private fun lockFolder(f: Folder) {
        val doLock = {
            Prefs.locked = Prefs.locked + f.id.toString()
            Prefs.hidden = Prefs.hidden - f.id.toString()
            render()
            Toast.makeText(this, R.string.folder_locked, Toast.LENGTH_LONG).show()
        }
        if (FolderLock.hasPin()) doLock() else FolderLock.create(this) { doLock() }
    }

    private fun confirmHide(f: Folder) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.hide_folder_title)
            .setMessage(getString(R.string.hide_folder_msg))
            .setPositiveButton(R.string.hide) { _, _ ->
                Prefs.hidden = Prefs.hidden + f.id.toString()
                render()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    companion object {
        const val EXTRA_LOCKED = "locked_mode"
    }
}
