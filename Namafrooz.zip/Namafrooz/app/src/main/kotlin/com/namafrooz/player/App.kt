package com.namafrooz.player

import android.app.Application
import androidx.appcompat.app.AppCompatDelegate

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
        AppCompatDelegate.setApplicationLocales(Prefs.localeList())
    }
}
