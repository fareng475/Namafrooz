package com.namafrooz.player

import android.widget.ScrollView
import android.content.Context
import android.content.ClipboardManager
import android.content.ClipData
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.graphics.ColorUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class SettingsActivity : BaseActivity() {

    private lateinit var box: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        box = findViewById(R.id.box)
        build()
    }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    private fun num(n: Int) = Loc.digits(this, n.toString())

    // ---------------------------------------------------------------- UI helpers

    private fun showErrorReport() {
        val text = CrashLog.read(this).ifEmpty { getString(R.string.error_none) }
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 11f
        tv.setTextIsSelectable(true)
        val pad = (20 * resources.displayMetrics.density).toInt()
        tv.setPadding(pad, pad / 2, pad, pad / 2)
        val sv = ScrollView(this)
        sv.addView(tv)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.error_report)
            .setView(sv)
            .setPositiveButton(R.string.error_copy) { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Namafrooz error report", text))
                Toast.makeText(this, R.string.copied, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.error_clear) { _, _ -> CrashLog.clear(this) }
            .setNeutralButton(android.R.string.ok, null)
            .show()
    }

    private fun section(titleRes: Int): LinearLayout {
        val header = TextView(this).apply {
            setText(titleRes)
            setTextColor(themeColor(R.attr.appAccent))
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), dp(20), dp(8), dp(8))
        }
        box.addView(header)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
        }
        box.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return card
    }

    private fun divider(card: LinearLayout) {
        if (card.childCount == 0) return
        val d = View(this)
        d.setBackgroundColor(ColorUtils.setAlphaComponent(themeColor(R.attr.appTextDim), 60))
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.marginStart = dp(16)
        lp.marginEnd = dp(16)
        card.addView(d, lp)
    }

    private fun row(card: LinearLayout, titleRes: Int, value: String, onClick: () -> Unit) {
        divider(card)
        val v = LayoutInflater.from(this).inflate(R.layout.item_setting, card, false)
        v.findViewById<TextView>(R.id.title).setText(titleRes)
        val tv = v.findViewById<TextView>(R.id.value)
        if (value.isEmpty()) tv.visibility = View.GONE else tv.text = value
        v.setOnClickListener { onClick() }
        card.addView(v)
    }

    private fun switchRow(card: LinearLayout, titleRes: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
        divider(card)
        val v = LayoutInflater.from(this).inflate(R.layout.item_setting, card, false)
        v.findViewById<TextView>(R.id.title).setText(titleRes)
        v.findViewById<TextView>(R.id.value).visibility = View.GONE
        val sw = v.findViewById<MaterialSwitch>(R.id.sw)
        sw.visibility = View.VISIBLE
        // all switches share the id "sw": never let Android save/restore their state, otherwise a
        // language change (activity re-creation) copies one switch state onto the others
        sw.isSaveEnabled = false
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, on -> onChange(on) }
        v.setOnClickListener { sw.toggle() }
        card.addView(v)
    }

    private fun choose(titleRes: Int, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        MaterialAlertDialogBuilder(this)
            .setTitle(titleRes)
            .setSingleChoiceItems(labels.toTypedArray(), selected) { d, which ->
                d.dismiss()
                onPick(which)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    // ---------------------------------------------------------------- screen

    private fun build() {
        box.isSaveFromParentEnabled = false
        box.removeAllViews()

        // ---- Language
        val langKeys = listOf("system", "fa", "en")
        val langLabels = listOf(getString(R.string.lang_system), "فارسی", "English")
        val langIdx = langKeys.indexOf(Prefs.language).coerceAtLeast(0)
        var c = section(R.string.sec_language)
        row(c, R.string.lang_label, langLabels[langIdx]) {
            choose(R.string.lang_label, langLabels, langIdx) { i ->
                Prefs.language = langKeys[i]
                AppCompatDelegate.setApplicationLocales(Prefs.localeList())
                build()
            }
        }

        // ---- Appearance
        val themeKeys = listOf("dark", "light", "system")
        val themeLabels = listOf(getString(R.string.theme_dark), getString(R.string.theme_light), getString(R.string.theme_system))
        val themeIdx = themeKeys.indexOf(Prefs.theme).coerceAtLeast(0)
        val accentKeys = listOf("gold", "blue", "green", "purple", "rose")
        val accentLabels = listOf(
            getString(R.string.accent_gold), getString(R.string.accent_blue), getString(R.string.accent_green),
            getString(R.string.accent_purple), getString(R.string.accent_rose)
        )
        val accentIdx = accentKeys.indexOf(Prefs.accent).coerceAtLeast(0)
        c = section(R.string.sec_appearance)
        row(c, R.string.theme_label, themeLabels[themeIdx]) {
            choose(R.string.theme_label, themeLabels, themeIdx) { i ->
                Prefs.theme = themeKeys[i]
                AppCompatDelegate.setDefaultNightMode(Prefs.nightMode())
                build()
            }
        }
        row(c, R.string.accent_label, accentLabels[accentIdx]) {
            choose(R.string.accent_label, accentLabels, accentIdx) { i ->
                Prefs.accent = accentKeys[i]
                recreate()
            }
        }
        val listSizeLabels = listOf(getString(R.string.size_small), getString(R.string.size_medium), getString(R.string.size_large))
        row(c, R.string.folder_size_label, listSizeLabels[Prefs.folderSize.coerceIn(0, 2)]) {
            choose(R.string.folder_size_label, listSizeLabels, Prefs.folderSize.coerceIn(0, 2)) { i ->
                Prefs.folderSize = i
                build()
            }
        }
        row(c, R.string.video_size_label, listSizeLabels[Prefs.videoSize.coerceIn(0, 2)]) {
            choose(R.string.video_size_label, listSizeLabels, Prefs.videoSize.coerceIn(0, 2)) { i ->
                Prefs.videoSize = i
                build()
            }
        }

        switchRow(c, R.string.folder_thumbs_label, Prefs.folderThumbs) { Prefs.folderThumbs = it }

        // ---- Playback
        val seekOpts = listOf(5, 10, 15, 30)
        val speedOpts = listOf(1.5f, 2f, 2.5f, 3f)
        c = section(R.string.sec_playback)
        row(c, R.string.skip_label, getString(R.string.seconds_value, Prefs.seekSeconds).let { Loc.digits(this, it) }) {
            val labels = seekOpts.map { Loc.digits(this, getString(R.string.seconds_value, it)) }
            choose(R.string.skip_label, labels, seekOpts.indexOf(Prefs.seekSeconds).coerceAtLeast(0)) { i ->
                Prefs.seekSeconds = seekOpts[i]
                build()
            }
        }
        row(c, R.string.speed_label, Loc.digits(this, "${Prefs.holdSpeed}x")) {
            val labels = speedOpts.map { Loc.digits(this, "${it}x") }
            choose(R.string.speed_label, labels, speedOpts.indexOf(Prefs.holdSpeed).coerceAtLeast(0)) { i ->
                Prefs.holdSpeed = speedOpts[i]
                build()
            }
        }
        switchRow(c, R.string.resume_label, Prefs.resume) { Prefs.resume = it }
        switchRow(c, R.string.autonext_label, Prefs.autoNext) { Prefs.autoNext = it }
        switchRow(c, R.string.swipe_label, Prefs.swipe) { Prefs.swipe = it }
        switchRow(c, R.string.zoom_label, Prefs.pinchZoom) { Prefs.pinchZoom = it }

        // ---- Subtitles
        val subSizeLabels = listOf(getString(R.string.size_small), getString(R.string.size_medium), getString(R.string.size_large), getString(R.string.size_xlarge))
        val colorLabels = listOf(getString(R.string.color_white), getString(R.string.color_yellow), getString(R.string.color_cyan), getString(R.string.color_green))
        val bgLabels = listOf(getString(R.string.bg_none), getString(R.string.bg_soft), getString(R.string.bg_dark))
        val posLabels = listOf(getString(R.string.pos_low), getString(R.string.pos_mid), getString(R.string.pos_high))
        c = section(R.string.sec_subtitles)
        val scales = listOf(50, 75, 100, 125, 150, 200)
        val scaleLabels = scales.map { Loc.digits(this, "$it%") }
        val scaleSel = scales.indices.minByOrNull { Math.abs(scales[it] - Prefs.subScale) } ?: 2
        row(c, R.string.sub_size_label, Loc.digits(this, "${Prefs.subScale}%")) {
            choose(R.string.sub_size_label, scaleLabels, scaleSel) { i ->
                Prefs.subScale = scales[i]
                build()
            }
        }
        row(c, R.string.style_color, colorLabels[Prefs.subColor.coerceIn(0, 3)]) {
            choose(R.string.style_color, colorLabels, Prefs.subColor.coerceIn(0, 3)) { i ->
                Prefs.subColor = i
                build()
            }
        }
        row(c, R.string.sub_bg_label, bgLabels[Prefs.subBg.coerceIn(0, 2)]) {
            choose(R.string.sub_bg_label, bgLabels, Prefs.subBg.coerceIn(0, 2)) { i ->
                Prefs.subBg = i
                build()
            }
        }
        row(c, R.string.style_pos, posLabels[Prefs.subPos.coerceIn(0, 2)]) {
            choose(R.string.style_pos, posLabels, Prefs.subPos.coerceIn(0, 2)) { i ->
                Prefs.subPos = i
                build()
            }
        }
        switchRow(c, R.string.weight_bold, Prefs.subBold) { Prefs.subBold = it }

        // ---- Folders
        val sortKeys = listOf("name", "count")
        val sortLabels = listOf(getString(R.string.sort_name), getString(R.string.sort_count))
        val sortIdx = sortKeys.indexOf(Prefs.sort).coerceAtLeast(0)
        c = section(R.string.sec_folders)
        row(c, R.string.sort_label, sortLabels[sortIdx]) {
            choose(R.string.sort_label, sortLabels, sortIdx) { i ->
                Prefs.sort = sortKeys[i]
                build()
            }
        }
        row(c, R.string.show_hidden_label, "") {
            Prefs.hidden = emptySet()
            Toast.makeText(this, R.string.show_hidden_done, Toast.LENGTH_SHORT).show()
        }
        row(c, R.string.lock_change_pin, "") { FolderLock.change(this) }
        row(c, R.string.lock_unlock_all, "") {
            FolderLock.enter(this) {
                Prefs.locked = emptySet()
                Toast.makeText(this, R.string.lock_unlock_all_done, Toast.LENGTH_SHORT).show()
            }
        }

        // ---- Data
        c = section(R.string.sec_data)
        row(c, R.string.clear_history, "") {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.clear_history)
                .setMessage(R.string.clear_history_msg)
                .setPositiveButton(R.string.clear) { _, _ ->
                    Prefs.clearHistory()
                    Toast.makeText(this, R.string.clear_done, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(R.string.cancel, null)
                .show()
        }

        // ---- About
        val version = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (_: Exception) {
            ""
        }
        c = section(R.string.sec_about)
        row(c, R.string.version_label, Loc.digits(this, version)) { }
        row(c, R.string.error_report, "") { showErrorReport() }
    }
}
