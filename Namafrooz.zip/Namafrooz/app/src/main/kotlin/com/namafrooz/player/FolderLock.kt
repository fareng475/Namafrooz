package com.namafrooz.player

import android.text.InputFilter
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.security.MessageDigest
import java.security.SecureRandom

/** A small PIN lock for the "locked folders" area. The PIN is stored only as a salted hash. */
object FolderLock {
    private fun hash(salt: String, pin: String): String {
        val md = MessageDigest.getInstance("SHA-256")
        var d = (salt + pin).toByteArray()
        repeat(2000) { d = md.digest(d) }
        return Base64.encodeToString(d, Base64.NO_WRAP)
    }

    /** Persian and Arabic digits are turned into normal digits so the PIN always matches. */
    private fun norm(s: String): String = s.map {
        when (it) {
            in '۰'..'۹' -> '0' + (it - '۰')
            in '٠'..'٩' -> '0' + (it - '٠')
            else -> it
        }
    }.joinToString("")

    fun hasPin(): Boolean = Prefs.lockHash.isNotEmpty()

    private fun setPin(pin: String) {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        val salt = Base64.encodeToString(bytes, Base64.NO_WRAP)
        Prefs.lockSalt = salt
        Prefs.lockHash = hash(salt, pin)
        Prefs.pinFails = 0
    }

    private fun check(pin: String): Boolean =
        hasPin() && hash(Prefs.lockSalt, pin) == Prefs.lockHash

    private fun pinDialog(act: AppCompatActivity, title: Int, message: String?, onPin: (String) -> Unit) {
        val d = act.resources.displayMetrics.density
        val et = EditText(act)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.hint = act.getString(R.string.pin_hint)
        et.filters = arrayOf(InputFilter.LengthFilter(8))
        et.textDirection = View.TEXT_DIRECTION_LTR
        et.gravity = Gravity.CENTER
        val box = FrameLayout(act)
        val pad = (24 * d).toInt()
        box.setPadding(pad, pad / 3, pad, 0)
        box.addView(et)
        val b = MaterialAlertDialogBuilder(act).setTitle(title).setView(box)
        if (message != null) b.setMessage(message)
        b.setPositiveButton(android.R.string.ok) { _, _ -> onPin(et.text.toString()) }
        b.setNegativeButton(R.string.cancel, null)
        val dlg = b.show()
        et.requestFocus()
        dlg.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** Asks for the PIN (or creates one the first time) and then runs [onOk]. */
    fun enter(act: AppCompatActivity, onOk: () -> Unit) {
        if (!hasPin()) {
            create(act, onOk)
            return
        }
        val wait = (Prefs.pinBlockedUntil - System.currentTimeMillis()) / 1000
        if (wait > 0) {
            Toast.makeText(act, act.getString(R.string.pin_wait, wait.toInt() + 1), Toast.LENGTH_LONG).show()
            return
        }
        pinDialog(act, R.string.pin_title_enter, null) { pin ->
            if (check(norm(pin))) {
                Prefs.pinFails = 0
                onOk()
            } else {
                val fails = Prefs.pinFails + 1
                if (fails >= 5) {
                    Prefs.pinFails = 0
                    Prefs.pinBlockedUntil = System.currentTimeMillis() + 30_000
                } else {
                    Prefs.pinFails = fails
                }
                Toast.makeText(act, R.string.pin_wrong, Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Creates a new PIN (asks twice) and then runs [onOk]. */
    fun create(act: AppCompatActivity, onOk: () -> Unit) {
        pinDialog(act, R.string.pin_title_create, act.getString(R.string.pin_create_msg)) { p1 ->
            val first = norm(p1)
            if (first.length < 4) {
                Toast.makeText(act, R.string.pin_short, Toast.LENGTH_SHORT).show()
                return@pinDialog
            }
            pinDialog(act, R.string.pin_title_confirm, null) { p2 ->
                if (norm(p2) == first) {
                    setPin(first)
                    onOk()
                } else {
                    Toast.makeText(act, R.string.pin_mismatch, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun change(act: AppCompatActivity) {
        enter(act) {
            create(act) { Toast.makeText(act, R.string.pin_changed, Toast.LENGTH_SHORT).show() }
        }
    }
}
