package com.namafrooz.player

import android.content.Context
import android.os.Looper
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.text.TextRenderer
import java.nio.ByteBuffer

/** Delays in milliseconds. Positive = later, negative = earlier. */
object SyncState {
    @Volatile var subDelayMs: Int = 0
    @Volatile var audioDelayMs: Int = 0
}

/** Adds silence (audio later) or drops the first samples (audio earlier) after every flush/seek. */
@UnstableApi
class AudioDelayProcessor : BaseAudioProcessor() {
    private var silenceBytes = 0
    private var skipBytes = 0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        return if (inputAudioFormat.encoding == C.ENCODING_PCM_16BIT) inputAudioFormat
        else AudioProcessor.AudioFormat.NOT_SET
    }

    override fun onFlush() {
        silenceBytes = 0
        skipBytes = 0
        val f = inputAudioFormat
        if (f.sampleRate <= 0 || f.bytesPerFrame <= 0) return
        val d = SyncState.audioDelayMs
        val frames = (Math.abs(d).toLong() * f.sampleRate / 1000L).toInt()
        val bytes = frames * f.bytesPerFrame
        if (d > 0) silenceBytes = bytes else if (d < 0) skipBytes = bytes
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        var remaining = inputBuffer.remaining()
        if (remaining == 0) return
        if (skipBytes > 0) {
            val s = minOf(skipBytes, remaining)
            inputBuffer.position(inputBuffer.position() + s)
            skipBytes -= s
            remaining -= s
            if (remaining == 0) return
        }
        val out = replaceOutputBuffer(silenceBytes + remaining)
        if (silenceBytes > 0) {
            out.put(ByteArray(silenceBytes))
            silenceBytes = 0
        }
        out.put(inputBuffer)
        out.flip()
    }
}

/** Text renderer that sees a shifted clock, so embedded and external subtitles can be moved. */
@UnstableApi
class OffsetTextRenderer(output: TextOutput, looper: Looper?) : TextRenderer(output, looper) {
    override fun render(positionUs: Long, elapsedRealtimeUs: Long) {
        super.render(positionUs - SyncState.subDelayMs * 1000L, elapsedRealtimeUs)
    }
}

@UnstableApi
class SyncRenderersFactory(context: Context) : DefaultRenderersFactory(context) {
    private val delay = AudioDelayProcessor()

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink? {
        return DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(enableFloatOutput)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
            .setAudioProcessors(arrayOf<AudioProcessor>(delay))
            .build()
    }

    override fun buildTextRenderers(
        context: Context,
        output: TextOutput,
        outputLooper: Looper,
        extensionRendererMode: Int,
        out: ArrayList<Renderer>
    ) {
        out.add(OffsetTextRenderer(output, outputLooper))
    }
}
