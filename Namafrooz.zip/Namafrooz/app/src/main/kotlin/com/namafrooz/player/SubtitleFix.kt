package com.namafrooz.player

import android.content.Context
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Many Persian/Arabic subtitle files are saved as Windows-1256; the player expects UTF-8. */
object SubtitleFix {
    fun toUtf8(ctx: Context, uri: Uri, name: String): Uri {
        if (uri.scheme == "file" && uri.path?.startsWith(ctx.filesDir.path) == true) return uri
        return try {
            val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return uri
            if (bytes.isEmpty() || bytes.size > 8_000_000) return uri
            val decoder = Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
            val text = try {
                decoder.decode(ByteBuffer.wrap(bytes)).toString()
            } catch (e: CharacterCodingException) {
                String(bytes, charset("windows-1256"))
            }
            val ext = Regex("\\.[A-Za-z0-9]{2,4}$").find(name)?.value ?: ".srt"
            val dir = File(ctx.cacheDir, "subs")
            dir.mkdirs()
            val f = File(dir, "sub_" + Math.abs(uri.hashCode()) + ext)
            f.writeText(text.removePrefix("\uFEFF"), Charsets.UTF_8)
            Uri.fromFile(f)
        } catch (e: Exception) {
            uri
        }
    }
}
