package com.namafrooz.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.max

/** Draws the splash artwork full-screen and animates the golden progress bar on top of it. */
class SplashView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private val bmp: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.splash_bg)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = 0f
    private var animator: ValueAnimator? = null

    // progress track position, in pixels of the artwork
    private val barLeft = 252f
    private val barRight = 686f
    private val barTop = 1114f
    private val barBottom = 1127.5f

    fun start(durationMs: Long) {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val s = max(width / bmp.width.toFloat(), height / bmp.height.toFloat())
        val dx = (width - bmp.width * s) / 2f
        val dy = (height - bmp.height * s) / 2f
        canvas.save()
        canvas.translate(dx, dy)
        canvas.scale(s, s)
        canvas.drawBitmap(bmp, 0f, 0f, bmpPaint)
        val w = (barRight - barLeft) * progress
        if (w > 2f) {
            fill.shader = LinearGradient(
                barLeft, 0f, barRight, 0f,
                intArrayOf(0xFFE6AA46.toInt(), 0xFFF7BF45.toInt(), 0xFFD69835.toInt()),
                null, Shader.TileMode.CLAMP
            )
            canvas.drawRoundRect(barLeft, barTop, barLeft + w, barBottom, 7f, 7f, fill)
        }
        canvas.restore()
    }
}
