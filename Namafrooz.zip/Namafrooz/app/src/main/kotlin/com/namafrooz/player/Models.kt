package com.namafrooz.player

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

data class Video(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val folderName: String,
    val folderId: Long
)

data class Folder(val id: Long, val name: String, val videos: List<Video>)

object PlaybackQueue {
    var items: List<Video> = emptyList()
    var start: Int = 0
}

object MediaRepo {
    fun load(context: Context): List<Folder> {
        val list = ArrayList<Video>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        context.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null, null
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val iName = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val iBid = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_ID)
            val iBn = c.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                list.add(
                    Video(
                        id,
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(iName) ?: "video",
                        c.getLong(iDur),
                        c.getString(iBn) ?: "Other",
                        c.getLong(iBid)
                    )
                )
            }
        }
        return list.groupBy { it.folderId }
            .map { (id, v) ->
                Folder(id, v.first().folderName, v.sortedWith { a, b -> naturalCompare(a.name, b.name) })
            }
            .sortedBy { it.name.lowercase() }
    }

    fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val pa = re.findAll(a.lowercase()).map { it.value }.toList()
        val pb = re.findAll(b.lowercase()).map { it.value }.toList()
        for (i in 0 until minOf(pa.size, pb.size)) {
            val x = pa[i]
            val y = pb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) x.toBigInteger().compareTo(y.toBigInteger()) else x.compareTo(y)
            if (c != 0) return c
        }
        return pa.size - pb.size
    }
}

fun formatTime(ms: Long): String {
    val s = ms / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

object Loc {
    private fun isFa(ctx: Context) = ctx.resources.configuration.locales[0].language == "fa"

    /** Shows Persian digits when the app language is Persian. */
    fun digits(ctx: Context, s: String): String {
        if (!isFa(ctx)) return s
        val sb = StringBuilder(s.length)
        for (ch in s) sb.append(if (ch in '0'..'9') ('\u06F0' + (ch - '0')) else ch)
        return sb.toString()
    }
}
