package com.namafrooz.player

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("namafrooz", Context.MODE_PRIVATE)
    }

    var seekSeconds: Int
        get() = sp.getInt("seek", 10)
        set(v) = sp.edit().putInt("seek", v).apply()

    var holdSpeed: Float
        get() = sp.getFloat("speed", 2f)
        set(v) = sp.edit().putFloat("speed", v).apply()

    var resume: Boolean
        get() = sp.getBoolean("resume", true)
        set(v) = sp.edit().putBoolean("resume", v).apply()

    fun savePos(key: String, pos: Long, dur: Long) {
        sp.edit().putLong("p_$key", pos).putLong("d_$key", dur).apply()
    }

    fun pos(key: String): Long = sp.getLong("p_$key", 0L)
    fun dur(key: String): Long = sp.getLong("d_$key", 0L)

    fun percent(key: String): Int {
        val d = dur(key)
        if (d <= 0) return 0
        return ((pos(key) * 100) / d).toInt().coerceIn(0, 100)
    }
}
