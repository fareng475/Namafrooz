package com.namafrooz.player

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("namafrooz", Context.MODE_PRIVATE)
    }

    // ---- playback ----
    var seekSeconds: Int
        get() = sp.getInt("seek", 10)
        set(v) = sp.edit().putInt("seek", v).apply()

    var holdSpeed: Float
        get() = sp.getFloat("speed", 2f)
        set(v) = sp.edit().putFloat("speed", v).apply()

    var resume: Boolean
        get() = sp.getBoolean("resume_v2", true)
        set(v) = sp.edit().putBoolean("resume_v2", v).apply()

    var autoNext: Boolean
        get() = sp.getBoolean("auto_next_v2", true)
        set(v) = sp.edit().putBoolean("auto_next_v2", v).apply()

    var swipe: Boolean
        get() = sp.getBoolean("swipe_v2", true)
        set(v) = sp.edit().putBoolean("swipe_v2", v).apply()

    /** Subtitle text size in percent (50..200). Old 4-step setting is converted on first use. */
    var subScale: Int
        get() = sp.getInt("sub_scale", when (sp.getInt("sub_size", 1)) { 0 -> 75; 2 -> 130; 3 -> 160; else -> 100 })
        set(v) = sp.edit().putInt("sub_scale", v.coerceIn(50, 200)).apply()

    var swipeSeek: Boolean
        get() = sp.getBoolean("swipe_seek", true)
        set(v) = sp.edit().putBoolean("swipe_seek", v).apply()

    // ---- subtitle look ----
    var subColor: Int // 0 white, 1 yellow, 2 cyan, 3 green
        get() = sp.getInt("sub_color", 0)
        set(v) = sp.edit().putInt("sub_color", v).apply()

    var subBg: Int // 0 outline only, 1 soft box, 2 dark box
        get() = sp.getInt("sub_bg", if (sp.getBoolean("sub_box", false)) 2 else 0)
        set(v) = sp.edit().putInt("sub_bg", v).apply()

    var subPos: Int // 0 low, 1 middle, 2 high
        get() = sp.getInt("sub_pos", 1)
        set(v) = sp.edit().putInt("sub_pos", v).apply()

    var subBold: Boolean
        get() = sp.getBoolean("sub_bold", false)
        set(v) = sp.edit().putBoolean("sub_bold", v).apply()

    var fitMode: Int // 0 fit, 1 crop, 2 stretch
        get() = sp.getInt("fit_mode", 0)
        set(v) = sp.edit().putInt("fit_mode", v).apply()

    // ---- subtitles ----
    /** 0 = small, 1 = medium, 2 = large */
    var subSize: Int
        get() = sp.getInt("sub_size", 1)
        set(v) = sp.edit().putInt("sub_size", v).apply()

    /** true = black box behind text, false = outline only */
    var subBox: Boolean
        get() = sp.getBoolean("sub_box", false)
        set(v) = sp.edit().putBoolean("sub_box", v).apply()

    // ---- appearance ----
    /** "system", "fa", "en" */
    var language: String
        get() = sp.getString("lang", "system") ?: "system"
        set(v) = sp.edit().putString("lang", v).apply()

    /** "dark", "light", "system" */
    var theme: String
        get() = sp.getString("theme", "dark") ?: "dark"
        set(v) = sp.edit().putString("theme", v).apply()

    /** "gold", "blue", "green", "purple", "rose" */
    var accent: String
        get() = sp.getString("accent", "gold") ?: "gold"
        set(v) = sp.edit().putString("accent", v).apply()

    fun localeList(): LocaleListCompat =
        if (language == "system") LocaleListCompat.getEmptyLocaleList()
        else LocaleListCompat.forLanguageTags(language)

    fun nightMode(): Int = when (theme) {
        "light" -> AppCompatDelegate.MODE_NIGHT_NO
        "system" -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
        else -> AppCompatDelegate.MODE_NIGHT_YES
    }

    fun accentStyle(): Int = when (accent) {
        "blue" -> R.style.Accent_Blue
        "green" -> R.style.Accent_Green
        "purple" -> R.style.Accent_Purple
        "rose" -> R.style.Accent_Rose
        else -> R.style.Accent_Gold
    }

    var pinchZoom: Boolean
        get() = sp.getBoolean("pinch_zoom", true)
        set(v) = sp.edit().putBoolean("pinch_zoom", v).apply()

    // ---- list sizes: 0 = small, 1 = medium, 2 = large ----
    var folderSize: Int
        get() = sp.getInt("folder_size", 1)
        set(v) = sp.edit().putInt("folder_size", v).apply()

    var videoSize: Int
        get() = sp.getInt("video_size", 1)
        set(v) = sp.edit().putInt("video_size", v).apply()

    // ---- folders ----
    /** "name" or "count" */
    var sort: String
        get() = sp.getString("sort", "name") ?: "name"
        set(v) = sp.edit().putString("sort", v).apply()

    var favorites: Set<String>
        get() = (sp.getStringSet("favorites", emptySet()) ?: emptySet()).toSet()
        set(v) = sp.edit().putStringSet("favorites", v.toSet()).apply()

    /** Returns true when the video is now a favorite. */
    fun toggleFavorite(key: String): Boolean {
        val s = favorites.toMutableSet()
        val added = s.add(key)
        if (!added) s.remove(key)
        favorites = s
        return added
    }

    fun subFile(key: String): String? = sp.getString("subfile_$key", null)
    fun setSubFile(key: String, path: String) = sp.edit().putString("subfile_$key", path).apply()

    var hidden: Set<String>
        get() = (sp.getStringSet("hidden", emptySet()) ?: emptySet()).toSet()
        set(v) = sp.edit().putStringSet("hidden", v.toSet()).apply()

    // ---- watch history ----
    var lastKey: String
        get() = sp.getString("last", "") ?: ""
        set(v) = sp.edit().putString("last", v).apply()

    fun savePos(key: String, pos: Long, dur: Long) {
        sp.edit().putLong("p_$key", pos).putLong("d_$key", dur).apply()
    }

    fun pos(key: String): Long = sp.getLong("p_$key", 0L)
    fun dur(key: String): Long = sp.getLong("d_$key", 0L)

    fun percent(key: String): Int {
        val d = dur(key)
        if (d <= 0) return 0
        return ((pos(key) * 100) / d).toInt().coerceIn(0, 100)
    }

    fun clearHistory() {
        val e = sp.edit()
        for (k in sp.all.keys) {
            if (k.startsWith("p_") || k.startsWith("d_")) e.remove(k)
        }
        e.remove("last")
        e.apply()
    }
}
