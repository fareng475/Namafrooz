package com.namafrooz.player

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SwitchCompat

/** The translucent settings panel that slides in at the side of the player. */
class PlayerPanel(
    private val act: ComponentActivity,
    private val root: ViewGroup,
    private val accent: Int,
    private val a: Actions
) {
    interface Actions {
        fun audioTracks()
        fun subtitleTracks()
        fun addSubtitleFile()
        fun currentSpeed(): Float
        fun setSpeed(s: Float)
        fun styleChanged()
        fun fitChanged()
        fun autoNextChanged()
        fun previewSubtitle(show: Boolean)
    }

    private class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private fun s(id: Int) = act.getString(id)

    private var scrim: FrameLayout? = null
    private var box: LinearLayout? = null
    private var page = 0 // 0 = main, 1 = subtitle look

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            if (page == 1) {
                page = 0
                a.previewSubtitle(false)
                render()
            } else hide()
        }
    }

    val isShown: Boolean get() = scrim != null

    fun toggle() = if (isShown) hide() else show()

    fun show() {
        if (scrim != null) return
        page = 0
        val dm = act.resources.displayMetrics
        val overlay = FrameLayout(act)
        overlay.setBackgroundColor(0x22000000)
        overlay.isClickable = true
        overlay.setOnClickListener { hide() }

        val scroll = MaxHeightScrollView(act, (dm.heightPixels * 0.88f).toInt())
        val content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(12), dp(16), dp(14))
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(0xD90E1A26.toInt())
        bg.setStroke(dp(1), 0x33FFFFFF)
        scroll.background = bg
        scroll.isClickable = true

        val w = minOf((dm.widthPixels * 0.52f).toInt(), dp(460))
        val lp = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
        lp.setMargins(dp(12), dp(12), dp(12), dp(12))
        overlay.addView(scroll, lp)
        root.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scrim = overlay
        box = content
        act.onBackPressedDispatcher.addCallback(act, backCb)
        render()
    }

    fun hide() {
        scrim?.let { root.removeView(it) }
        scrim = null
        box = null
        backCb.remove()
        a.previewSubtitle(false)
    }

    private fun render() {
        val b = box ?: return
        b.removeAllViews()
        if (page == 0) buildMain(b) else buildStyle(b)
    }

    // ------------------------------------------------------------ pages

    private fun buildMain(b: LinearLayout) {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = label(s(R.string.settings), 17f, Color.WHITE, true)
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = label("✕", 18f, Color.WHITE, false)
        close.setPadding(dp(10), dp(4), dp(10), dp(4))
        close.setOnClickListener { hide() }
        head.addView(close)
        b.addView(head)

        b.addView(section(s(R.string.panel_tracks)))
        val tiles = LinearLayout(act)
        tiles.orientation = LinearLayout.HORIZONTAL
        tiles.addView(tile("♪", s(R.string.tile_audio)) { hide(); a.audioTracks() }, tileLp())
        tiles.addView(tile("CC", s(R.string.tile_subs)) { hide(); a.subtitleTracks() }, tileLp())
        tiles.addView(tile("+", s(R.string.tile_add)) { hide(); a.addSubtitleFile() }, tileLp())
        tiles.addView(tile("Aa", s(R.string.tile_style)) {
            page = 1
            a.previewSubtitle(true)
            render()
        }, tileLp())
        b.addView(tiles)

        b.addView(section(s(R.string.panel_speed)))
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val sel = speeds.indexOfFirst { Math.abs(it - a.currentSpeed()) < 0.01f }
        b.addView(chips(speeds.map { Loc.digits(act, "${it}x") }, sel) {
            a.setSpeed(speeds[it])
            render()
        })

        b.addView(section(s(R.string.panel_picture)))
        b.addView(chips(listOf(s(R.string.fit_fit), s(R.string.fit_crop), s(R.string.fit_stretch)), Prefs.fitMode.coerceIn(0, 2)) {
            Prefs.fitMode = it
            a.fitChanged()
            render()
        })

        b.addView(section(s(R.string.panel_quick)))
        b.addView(switchRow(s(R.string.swipe_label), Prefs.swipe) { Prefs.swipe = it })
        b.addView(switchRow(s(R.string.zoom_label), Prefs.pinchZoom) { Prefs.pinchZoom = it })
        b.addView(switchRow(s(R.string.autonext_label), Prefs.autoNext) {
            Prefs.autoNext = it
            a.autoNextChanged()
        })
    }

    private fun buildStyle(b: LinearLayout) {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val back = label("‹ " + s(R.string.back), 14f, accent, true)
        back.setPadding(0, dp(4), dp(12), dp(4))
        back.setOnClickListener {
            page = 0
            a.previewSubtitle(false)
            render()
        }
        head.addView(back)
        head.addView(label(s(R.string.style_title), 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        b.addView(head)

        b.addView(section(s(R.string.style_size)))
        b.addView(chips(
            listOf(s(R.string.size_small), s(R.string.size_medium), s(R.string.size_large), s(R.string.size_xlarge)),
            Prefs.subSize.coerceIn(0, 3)
        ) { Prefs.subSize = it; changed() })

        b.addView(section(s(R.string.style_color)))
        b.addView(colorDots(Prefs.subColor.coerceIn(0, 3)) { Prefs.subColor = it; changed() })

        b.addView(section(s(R.string.style_bg)))
        b.addView(chips(listOf(s(R.string.bg_none), s(R.string.bg_soft), s(R.string.bg_dark)), Prefs.subBg.coerceIn(0, 2)) {
            Prefs.subBg = it
            changed()
        })

        b.addView(section(s(R.string.style_pos)))
        b.addView(chips(listOf(s(R.string.pos_low), s(R.string.pos_mid), s(R.string.pos_high)), Prefs.subPos.coerceIn(0, 2)) {
            Prefs.subPos = it
            changed()
        })

        b.addView(section(s(R.string.style_weight)))
        b.addView(chips(listOf(s(R.string.weight_normal), s(R.string.weight_bold)), if (Prefs.subBold) 1 else 0) {
            Prefs.subBold = it == 1
            changed()
        })
    }

    private fun changed() {
        a.styleChanged()
        a.previewSubtitle(true)
        render()
    }

    // ------------------------------------------------------------ pieces

    private fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, android.graphics.Typeface.BOLD)
        return v
    }

    private fun section(t: String): TextView {
        val v = label(t, 12f, 0xB3FFFFFF.toInt(), false)
        v.setPadding(dp(2), dp(14), 0, dp(6))
        return v
    }

    private fun round(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(color)
        return g
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        labels.forEachIndexed { i, t ->
            val on = i == selected
            val c = label(t, 13f, if (on) 0xFF1A1200.toInt() else Color.WHITE, on)
            c.gravity = Gravity.CENTER
            c.maxLines = 1
            c.setPadding(dp(4), dp(9), dp(4), dp(9))
            c.background = round(if (on) accent else 0x26FFFFFF, 12)
            c.setOnClickListener { onPick(i) }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            row.addView(c, lp)
        }
        return row
    }

    private fun colorDots(selected: Int, onPick: (Int) -> Unit): View {
        val colors = intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4DD0E1.toInt(), 0xFF69F0AE.toInt())
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        colors.forEachIndexed { i, col ->
            val dot = View(act)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(if (i == selected) 3 else 1), if (i == selected) accent else 0x66FFFFFF)
            dot.background = g
            dot.setOnClickListener { onPick(i) }
            val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
            lp.setMargins(dp(10), 0, dp(10), 0)
            row.addView(dot, lp)
        }
        return row
    }

    private fun tileLp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun tile(glyph: String, text: String, onClick: () -> Unit): View {
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, dp(4), 0, dp(4))
        val circle = label(glyph, 18f, Color.WHITE, true)
        circle.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0x26FFFFFF)
        g.setStroke(dp(1), 0x66FFFFFF)
        circle.background = g
        col.addView(circle, LinearLayout.LayoutParams(dp(50), dp(50)))
        val t = label(text, 11f, Color.WHITE, false)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.setPadding(0, dp(6), 0, 0)
        col.addView(t)
        col.setOnClickListener { onClick() }
        return col
    }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(2), dp(4), dp(2), dp(4))
        row.addView(label(text, 14f, Color.WHITE, false), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(act)
        sw.isSaveEnabled = false
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        row.addView(sw)
        return row
    }
}
