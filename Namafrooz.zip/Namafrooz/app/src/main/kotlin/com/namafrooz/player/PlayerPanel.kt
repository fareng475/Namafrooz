package com.namafrooz.player

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.widget.SwitchCompat
import java.io.File
import java.util.Locale

/** The translucent settings panel that opens at the side of the player. */
class PlayerPanel(
    private val act: ComponentActivity,
    private val root: ViewGroup,
    private val accent: Int,
    private val a: Actions
) {
    interface Actions {
        fun audioTracks()
        fun subtitleTracks()
        fun addSubtitleFile()
        fun currentSpeed(): Float
        fun setSpeed(s: Float)
        fun styleChanged()
        fun fitChanged()
        fun autoNextChanged()
        fun previewSubtitle(show: Boolean)
        fun syncValue(mode: Int): Int // mode 0 = subtitle, 1 = audio (milliseconds)
        fun syncSet(mode: Int, ms: Int)
        fun hasFileAccess(): Boolean
        fun requestFileAccess()
        fun startDir(): File?
        fun videoBaseName(): String
        fun pickSubtitle(file: File)
    }

    private class MaxHeightScrollView(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
        override fun onMeasure(w: Int, h: Int) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST))
        }
    }

    private val d = act.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()
    private fun s(id: Int) = act.getString(id)

    private var scrim: FrameLayout? = null
    private var box: LinearLayout? = null
    private var page = 0 // 0 = main, 1 = subtitle look, 2 = file browser
    private var dir: File? = null
    private val storageRoot: File = Environment.getExternalStorageDirectory()

    private val backCb = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            when (page) {
                1 -> {
                    page = 0
                    a.previewSubtitle(false)
                    render()
                }
                2 -> {
                    if (!goUp()) page = 0
                    render()
                }
                else -> hide()
            }
        }
    }

    val isShown: Boolean get() = scrim != null

    fun toggle() = if (isShown) hide() else show()

    fun refresh() {
        if (isShown) render()
    }

    fun show() {
        if (scrim != null) return
        page = 0
        val dm = act.resources.displayMetrics
        val overlay = FrameLayout(act)
        overlay.setBackgroundColor(0x22000000)
        overlay.isClickable = true
        overlay.setOnClickListener { hide() }

        val scroll = MaxHeightScrollView(act, (dm.heightPixels * 0.88f).toInt())
        val content = LinearLayout(act)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(12), dp(16), dp(14))
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(20).toFloat()
        bg.setColor(0xD90E1A26.toInt())
        bg.setStroke(dp(1), 0x33FFFFFF)
        scroll.background = bg
        scroll.isClickable = true

        val w = minOf((dm.widthPixels * 0.52f).toInt(), dp(460))
        val lp = FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
        lp.setMargins(dp(12), dp(12), dp(12), dp(12))
        overlay.addView(scroll, lp)
        root.addView(overlay, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        scrim = overlay
        box = content
        act.onBackPressedDispatcher.addCallback(act, backCb)
        render()
    }

    fun hide() {
        scrim?.let { root.removeView(it) }
        scrim = null
        box = null
        backCb.remove()
        a.previewSubtitle(false)
    }

    private fun render() {
        val b = box ?: return
        b.removeAllViews()
        when (page) {
            0 -> buildMain(b)
            1 -> buildStyle(b)
            else -> buildFiles(b)
        }
    }

    // ------------------------------------------------------------ main page

    private fun buildMain(b: LinearLayout) {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label(s(R.string.settings), 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val close = label("✕", 18f, Color.WHITE, false)
        close.setPadding(dp(10), dp(4), dp(10), dp(4))
        close.setOnClickListener { hide() }
        head.addView(close)
        b.addView(head)

        // ---- audio
        b.addView(section(s(R.string.tile_audio)))
        val audioTiles = LinearLayout(act)
        audioTiles.orientation = LinearLayout.HORIZONTAL
        audioTiles.addView(tile("♪", s(R.string.tile_track)) { hide(); a.audioTracks() }, tileLp())
        b.addView(audioTiles)
        b.addView(syncRow(1))

        // ---- subtitles
        b.addView(section(s(R.string.tile_subs)))
        val subTiles = LinearLayout(act)
        subTiles.orientation = LinearLayout.HORIZONTAL
        subTiles.addView(tile("CC", s(R.string.tile_track)) { hide(); a.subtitleTracks() }, tileLp())
        subTiles.addView(tile("+", s(R.string.tile_add)) {
            page = 2
            dir = null
            render()
        }, tileLp())
        subTiles.addView(tile("Aa", s(R.string.tile_style)) {
            page = 1
            a.previewSubtitle(true)
            render()
        }, tileLp())
        b.addView(subTiles)
        b.addView(syncRow(0))

        // ---- speed
        b.addView(section(s(R.string.panel_speed)))
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val sel = speeds.indexOfFirst { Math.abs(it - a.currentSpeed()) < 0.01f }
        b.addView(chips(speeds.map { Loc.digits(act, "${it}x") }, sel) {
            a.setSpeed(speeds[it])
            render()
        })

        // ---- picture
        b.addView(section(s(R.string.panel_picture)))
        b.addView(chips(listOf(s(R.string.fit_fit), s(R.string.fit_crop), s(R.string.fit_stretch)), Prefs.fitMode.coerceIn(0, 2)) {
            Prefs.fitMode = it
            a.fitChanged()
            render()
        })

        // ---- quick switches
        b.addView(section(s(R.string.panel_quick)))
        b.addView(switchRow(s(R.string.swipe_label), Prefs.swipe) { Prefs.swipe = it })
        b.addView(switchRow(s(R.string.zoom_label), Prefs.pinchZoom) { Prefs.pinchZoom = it })
        b.addView(switchRow(s(R.string.autonext_label), Prefs.autoNext) {
            Prefs.autoNext = it
            a.autoNextChanged()
        })
    }

    /** "Sync  [-0.5] [-0.1]  +0.0 s  [+0.1] [+0.5]" for subtitles (mode 0) or audio (mode 1). */
    private fun syncRow(mode: Int): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(2), dp(6), dp(2), 0)
        row.addView(label(s(R.string.sync_word), 13f, 0xB3FFFFFF.toInt(), false), LinearLayout.LayoutParams(dp(60), ViewGroup.LayoutParams.WRAP_CONTENT))
        val value = label("", 13f, accent, true)
        value.gravity = Gravity.CENTER
        value.maxLines = 1
        fun show() {
            val v = a.syncValue(mode)
            val sign = if (v > 0) "+" else if (v < 0) "−" else ""
            val num = String.format(Locale.US, "%.1f", Math.abs(v) / 1000f)
            value.text = Loc.digits(act, act.getString(R.string.sync_value, sign + num))
        }
        fun step(text: String, delta: Int): TextView {
            val c = label(text, 12f, Color.WHITE, true)
            c.gravity = Gravity.CENTER
            c.maxLines = 1
            c.setPadding(dp(2), dp(8), dp(2), dp(8))
            c.background = round(0x26FFFFFF, 10)
            c.setOnClickListener {
                a.syncSet(mode, a.syncValue(mode) + delta)
                show()
            }
            return c
        }
        fun lp(weight: Float): LinearLayout.LayoutParams {
            val l = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
            l.setMargins(dp(2), 0, dp(2), 0)
            return l
        }
        row.addView(step("−0.5", -500), lp(1f))
        row.addView(step("−0.1", -100), lp(1f))
        row.addView(value, lp(1.7f))
        row.addView(step("+0.1", 100), lp(1f))
        row.addView(step("+0.5", 500), lp(1f))
        value.setOnClickListener {
            a.syncSet(mode, 0)
            show()
        }
        show()
        return row
    }

    // ------------------------------------------------------------ subtitle look page

    private fun buildStyle(b: LinearLayout) {
        b.addView(pageHeader(s(R.string.style_title)) {
            page = 0
            a.previewSubtitle(false)
            render()
        })

        b.addView(section(s(R.string.style_size)))
        b.addView(chips(
            listOf(s(R.string.size_small), s(R.string.size_medium), s(R.string.size_large), s(R.string.size_xlarge)),
            Prefs.subSize.coerceIn(0, 3)
        ) { Prefs.subSize = it; changed() })

        b.addView(section(s(R.string.style_color)))
        b.addView(colorDots(Prefs.subColor.coerceIn(0, 3)) { Prefs.subColor = it; changed() })

        b.addView(section(s(R.string.style_bg)))
        b.addView(chips(listOf(s(R.string.bg_none), s(R.string.bg_soft), s(R.string.bg_dark)), Prefs.subBg.coerceIn(0, 2)) {
            Prefs.subBg = it
            changed()
        })

        b.addView(section(s(R.string.style_pos)))
        b.addView(chips(listOf(s(R.string.pos_low), s(R.string.pos_mid), s(R.string.pos_high)), Prefs.subPos.coerceIn(0, 2)) {
            Prefs.subPos = it
            changed()
        })

        b.addView(section(s(R.string.style_weight)))
        b.addView(chips(listOf(s(R.string.weight_normal), s(R.string.weight_bold)), if (Prefs.subBold) 1 else 0) {
            Prefs.subBold = it == 1
            changed()
        })
    }

    private fun changed() {
        a.styleChanged()
        a.previewSubtitle(true)
        render()
    }

    // ------------------------------------------------------------ file browser page

    private val subExt = setOf("srt", "ass", "ssa", "vtt")

    private fun goUp(): Boolean {
        val c = dir ?: return false
        if (c.path == storageRoot.path) return false
        val p = c.parentFile ?: return false
        dir = p
        return true
    }

    private fun buildFiles(b: LinearLayout) {
        if (dir == null) dir = a.startDir() ?: storageRoot
        val cur = dir!!
        b.addView(pageHeader(s(R.string.add_subtitle)) {
            if (!goUp()) page = 0
            render()
        })
        val path = label(cur.path, 11f, 0x99FFFFFF.toInt(), false)
        path.setPadding(dp(2), dp(6), 0, dp(6))
        b.addView(path)

        if (!a.hasFileAccess()) {
            b.addView(label(s(R.string.files_allow), 13f, Color.WHITE, false))
            val btn = label(s(R.string.files_allow_btn), 14f, 0xFF1A1200.toInt(), true)
            btn.gravity = Gravity.CENTER
            btn.setPadding(dp(12), dp(10), dp(12), dp(10))
            btn.background = round(accent, 12)
            btn.setOnClickListener { a.requestFileAccess() }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(12)
            b.addView(btn, lp)
            return
        }

        val kids = cur.listFiles()?.filter { !it.name.startsWith(".") } ?: emptyList()
        val folders = kids.filter { it.isDirectory }.sortedBy { it.name.lowercase() }
        val vb = a.videoBaseName().lowercase()
        fun matches(f: File): Boolean {
            if (vb.isEmpty()) return false
            val n = f.nameWithoutExtension.lowercase()
            return n == vb || n.startsWith(vb) || vb.startsWith(n)
        }
        val files = kids.filter { it.isFile && it.extension.lowercase() in subExt }
            .sortedWith(compareByDescending<File> { matches(it) }.thenBy { it.name.lowercase() })

        if (folders.isEmpty() && files.isEmpty()) {
            b.addView(label(s(R.string.files_empty), 13f, 0xB3FFFFFF.toInt(), false))
            return
        }
        for (f in folders) {
            b.addView(fileRow(R.drawable.ic_folder, f.name, false) {
                dir = f
                render()
            })
        }
        for (f in files) {
            b.addView(fileRow(R.drawable.ic_file, f.name, matches(f)) {
                hide()
                a.pickSubtitle(f)
            })
        }
    }

    private fun fileRow(icon: Int, name: String, highlight: Boolean, onClick: () -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(4), dp(10), dp(4), dp(10))
        val img = ImageView(act)
        img.setImageResource(icon)
        row.addView(img, LinearLayout.LayoutParams(dp(28), dp(28)))
        val t = label(name, 14f, if (highlight) accent else Color.WHITE, highlight)
        t.maxLines = 2
        t.setPadding(dp(14), 0, 0, 0)
        row.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener { onClick() }
        return row
    }

    // ------------------------------------------------------------ pieces

    private fun pageHeader(title: String, onBack: () -> Unit): View {
        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val back = label("←", 20f, accent, true)
        back.setPadding(dp(2), dp(4), dp(14), dp(4))
        back.setOnClickListener { onBack() }
        head.addView(back)
        head.addView(label(title, 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return head
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean): TextView {
        val v = TextView(act)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun section(t: String): TextView {
        val v = label(t, 12f, 0xB3FFFFFF.toInt(), false)
        v.setPadding(dp(2), dp(14), 0, dp(6))
        return v
    }

    private fun round(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(radiusDp).toFloat()
        g.setColor(color)
        return g
    }

    private fun chips(labels: List<String>, selected: Int, onPick: (Int) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        labels.forEachIndexed { i, t ->
            val on = i == selected
            val c = label(t, 13f, if (on) 0xFF1A1200.toInt() else Color.WHITE, on)
            c.gravity = Gravity.CENTER
            c.maxLines = 1
            c.setPadding(dp(4), dp(9), dp(4), dp(9))
            c.background = round(if (on) accent else 0x26FFFFFF, 12)
            c.setOnClickListener { onPick(i) }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            row.addView(c, lp)
        }
        return row
    }

    private fun colorDots(selected: Int, onPick: (Int) -> Unit): View {
        val colors = intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4DD0E1.toInt(), 0xFF69F0AE.toInt())
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        colors.forEachIndexed { i, col ->
            val dot = View(act)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(col)
            g.setStroke(dp(if (i == selected) 3 else 1), if (i == selected) accent else 0x66FFFFFF)
            dot.background = g
            dot.setOnClickListener { onPick(i) }
            val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
            lp.setMargins(dp(10), 0, dp(10), 0)
            row.addView(dot, lp)
        }
        return row
    }

    private fun tileLp() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)

    private fun tile(glyph: String, text: String, onClick: () -> Unit): View {
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(0, dp(4), 0, dp(4))
        val circle = label(glyph, 18f, Color.WHITE, true)
        circle.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0x26FFFFFF)
        g.setStroke(dp(1), 0x66FFFFFF)
        circle.background = g
        col.addView(circle, LinearLayout.LayoutParams(dp(50), dp(50)))
        val t = label(text, 11f, Color.WHITE, false)
        t.gravity = Gravity.CENTER
        t.maxLines = 2
        t.setPadding(0, dp(6), 0, 0)
        col.addView(t)
        col.setOnClickListener { onClick() }
        return col
    }

    private fun switchRow(text: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        val row = LinearLayout(act)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(2), dp(4), dp(2), dp(4))
        row.addView(label(text, 14f, Color.WHITE, false), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = SwitchCompat(act)
        sw.isSaveEnabled = false
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        row.addView(sw)
        return row
    }
}
