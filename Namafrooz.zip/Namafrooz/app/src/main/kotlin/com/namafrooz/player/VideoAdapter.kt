package com.namafrooz.player

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class VideoAdapter(
    private val onFolder: (Folder) -> Unit,
    private val onVideo: (List<Video>, Int) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<Any> = emptyList()

    fun submit(list: List<Any>) {
        rows = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = rows.size
    override fun getItemViewType(position: Int) = if (rows[position] is Folder) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == 0) FolderVH(inf.inflate(R.layout.item_folder, parent, false))
        else VideoVH(inf.inflate(R.layout.item_video, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = rows[position]
        if (holder is FolderVH && item is Folder) holder.bind(item)
        if (holder is VideoVH && item is Video) holder.bind(item)
    }

    inner class FolderVH(v: View) : RecyclerView.ViewHolder(v) {
        private val name: TextView = v.findViewById(R.id.name)
        private val info: TextView = v.findViewById(R.id.info)
        fun bind(f: Folder) {
            name.text = f.name
            val watched = f.videos.count { Prefs.percent(it.uri.toString()) >= 95 }
            info.text = itemView.context.getString(R.string.folder_info, f.videos.size, watched)
            itemView.setOnClickListener { onFolder(f) }
        }
    }

    inner class VideoVH(v: View) : RecyclerView.ViewHolder(v) {
        private val thumb: ImageView = v.findViewById(R.id.thumb)
        private val dur: TextView = v.findViewById(R.id.dur)
        private val prog: ProgressBar = v.findViewById(R.id.prog)
        private val name: TextView = v.findViewById(R.id.name)
        private val status: TextView = v.findViewById(R.id.status)

        fun bind(v: Video) {
            val ctx = itemView.context
            name.text = v.name
            dur.text = formatTime(v.durationMs)
            Glide.with(thumb).load(v.uri).centerCrop().into(thumb)
            val pct = Prefs.percent(v.uri.toString())
            prog.progress = pct
            status.text = when {
                pct >= 95 -> ctx.getString(R.string.status_done)
                pct > 0 -> ctx.getString(R.string.status_pct, pct)
                else -> ctx.getString(R.string.status_new)
            }
            itemView.setOnClickListener {
                val list = rows.filterIsInstance<Video>()
                onVideo(list, list.indexOf(v))
            }
        }
    }
}
