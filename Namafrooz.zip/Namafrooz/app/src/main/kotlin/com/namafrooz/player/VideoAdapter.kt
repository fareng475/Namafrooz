package com.namafrooz.player

import androidx.core.graphics.ColorUtils
import android.content.Context
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class VideoAdapter(
    private val onFolder: (Folder) -> Unit,
    private val onFolderLong: (Folder) -> Unit,
    private val onVideo: (List<Video>, Int) -> Unit,
    private val onVideoLong: (Video) -> Unit = {}
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private var rows: List<Any> = emptyList()

    // index = Prefs size (0 small, 1 medium, 2 large)
    private val folderThumb = arrayOf(64 to 48, 88 to 64, 116 to 84)
    private val folderName = floatArrayOf(15f, 17f, 19f)
    private val folderInfo = floatArrayOf(11.5f, 13f, 14.5f)
    private val videoThumb = arrayOf(96 to 54, 132 to 76, 176 to 99)
    private val videoName = floatArrayOf(13f, 15f, 17f)
    private val videoStatus = floatArrayOf(11f, 12f, 13.5f)
    private val videoDur = floatArrayOf(10f, 11f, 12.5f)

    private fun sizeBox(box: View, wDp: Int, hDp: Int) {
        val d = box.resources.displayMetrics.density
        val lp = box.layoutParams
        lp.width = (wDp * d).toInt()
        lp.height = (hDp * d).toInt()
        box.layoutParams = lp
    }

    fun submit(list: List<Any>) {
        rows = list
        notifyDataSetChanged()
    }

    override fun getItemCount() = rows.size
    override fun getItemViewType(position: Int) = if (rows[position] is Folder) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(parent.context)
        return if (viewType == 0) FolderVH(inf.inflate(R.layout.item_folder, parent, false))
        else VideoVH(inf.inflate(R.layout.item_video, parent, false))
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = rows[position]
        if (holder is FolderVH && item is Folder) holder.bind(item)
        if (holder is VideoVH && item is Video) holder.bind(item)
    }

    inner class FolderVH(v: View) : RecyclerView.ViewHolder(v) {
        private val thumb: ImageView = v.findViewById(R.id.thumb)
        private val name: TextView = v.findViewById(R.id.name)
        private val info: TextView = v.findViewById(R.id.info)
        private val prog: ProgressBar = v.findViewById(R.id.prog)
        private val baseNameColor = name.currentTextColor

        private fun accentColor(ctx: Context): Int {
            val tv = TypedValue()
            ctx.theme.resolveAttribute(R.attr.appAccent, tv, true)
            return tv.data
        }

        fun bind(f: Folder) {
            val ctx = itemView.context
            val sz = Prefs.folderSize.coerceIn(0, 2)
            sizeBox(itemView.findViewById(R.id.thumbBox), folderThumb[sz].first, folderThumb[sz].second)
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, folderName[sz])
            info.setTextSize(TypedValue.COMPLEX_UNIT_SP, folderInfo[sz])
            name.text = f.name
            val last = Prefs.lastKey
            val isLast = f.id != -777L && last.isNotEmpty() && f.videos.any { it.uri.toString() == last }
            name.setTextColor(if (isLast) ColorUtils.blendARGB(baseNameColor, accentColor(ctx), 0.62f) else baseNameColor)
            val total = f.videos.size
            val videosText = ctx.resources.getQuantityString(R.plurals.videos_count, total, total)
            info.text = Loc.digits(ctx, videosText)
            prog.visibility = View.GONE

            val first = f.videos.firstOrNull()
            if (first != null) {
                Glide.with(thumb).load(first.uri).centerCrop().into(thumb)
            } else {
                Glide.with(thumb).clear(thumb)
                thumb.setImageDrawable(null)
            }
            itemView.setOnClickListener { onFolder(f) }
            itemView.setOnLongClickListener { onFolderLong(f); true }
        }
    }

    inner class VideoVH(v: View) : RecyclerView.ViewHolder(v) {
        private val thumb: ImageView = v.findViewById(R.id.thumb)
        private val dur: TextView = v.findViewById(R.id.dur)
        private val prog: ProgressBar = v.findViewById(R.id.prog)
        private val name: TextView = v.findViewById(R.id.name)
        private val status: TextView = v.findViewById(R.id.status)

        fun bind(v: Video) {
            val ctx = itemView.context
            val sz = Prefs.videoSize.coerceIn(0, 2)
            sizeBox(itemView.findViewById(R.id.thumbBox), videoThumb[sz].first, videoThumb[sz].second)
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, videoName[sz])
            status.setTextSize(TypedValue.COMPLEX_UNIT_SP, videoStatus[sz])
            dur.setTextSize(TypedValue.COMPLEX_UNIT_SP, videoDur[sz])
            name.text = (if (Prefs.favorites.contains(v.uri.toString())) "★ " else "") + v.name
            dur.text = Loc.digits(ctx, formatTime(v.durationMs))
            Glide.with(thumb).load(v.uri).centerCrop().into(thumb)
            val pct = Prefs.percent(v.uri.toString())
            prog.progress = pct
            status.text = when {
                pct >= 95 -> ctx.getString(R.string.status_done)
                pct > 0 -> Loc.digits(ctx, ctx.getString(R.string.status_pct, pct))
                else -> ctx.getString(R.string.status_new)
            }
            itemView.setOnLongClickListener {
                onVideoLong(v)
                true
            }
            itemView.setOnClickListener {
                val list = rows.filterIsInstance<Video>()
                onVideo(list, list.indexOf(v))
            }
        }
    }
}
