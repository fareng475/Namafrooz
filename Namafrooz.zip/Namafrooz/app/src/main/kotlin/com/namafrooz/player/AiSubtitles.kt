package com.namafrooz.player

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.SpeechSegment
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.io.File
import java.nio.ByteOrder
import java.security.MessageDigest
import java.util.Locale

/**
 * Offline English subtitles: decode the audio track, cut it into speech parts with a voice
 * activity detector, then let Whisper (running on the phone, no internet) write the text.
 */
object AiSubtitles {
    class Cancelled : Exception()

    private data class Line(val start: Float, val end: Float, val text: String)

    fun cacheFile(ctx: Context, uri: Uri): File {
        val h = MessageDigest.getInstance("SHA-1").digest(uri.toString().toByteArray())
            .joinToString("") { "%02x".format(it) }
        return File(File(ctx.filesDir, "subs"), "$h.en.srt")
    }

    fun generate(ctx: Context, uri: Uri, onProgress: (Int) -> Unit, isCancelled: () -> Boolean): File {
        val threads = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)
        val recognizer = OfflineRecognizer(
            assetManager = ctx.assets,
            config = OfflineRecognizerConfig(
                featConfig = FeatureConfig(),
                modelConfig = OfflineModelConfig(
                    whisper = OfflineWhisperModelConfig(
                        encoder = "ai/whisper-encoder.onnx",
                        decoder = "ai/whisper-decoder.onnx",
                        language = "en",
                        task = "transcribe"
                    ),
                    tokens = "ai/whisper-tokens.txt",
                    numThreads = threads,
                    debug = false,
                    provider = "cpu",
                    modelType = "whisper"
                )
            )
        )
        val vad = Vad(
            assetManager = ctx.assets,
            config = VadModelConfig(
                sileroVadModelConfig = SileroVadModelConfig(
                    model = "ai/silero_vad.onnx",
                    threshold = 0.5f,
                    minSilenceDuration = 0.4f,
                    minSpeechDuration = 0.25f,
                    windowSize = 512,
                    maxSpeechDuration = 12f
                ),
                sampleRate = 16000,
                numThreads = 1,
                provider = "cpu",
                debug = false
            )
        )

        val lines = ArrayList<Line>()
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            fun handle(seg: SpeechSegment) {
                val stream = recognizer.createStream()
                stream.acceptWaveform(seg.samples, 16000)
                recognizer.decode(stream)
                val text = recognizer.getResult(stream).text.trim()
                stream.release()
                val clean = text.replace(Regex("\\s+"), " ")
                val skip = clean.length < 2 ||
                    (clean.startsWith("[") && clean.endsWith("]")) ||
                    (clean.startsWith("(") && clean.endsWith(")"))
                if (!skip) {
                    val s = seg.start / 16000f
                    lines.add(Line(s, s + seg.samples.size / 16000f, clean))
                }
            }

            fun drain() {
                while (!vad.empty()) {
                    val seg = vad.front()
                    vad.pop()
                    handle(seg)
                }
            }

            // ---- audio decoding ----
            extractor.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: ""
                if (m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) throw Exception("No audio track")
            extractor.selectTrack(track)
            val fmt = extractor.getTrackFormat(track)
            val durationUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
            var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val dec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()

            // streaming resampler to 16 kHz mono (box filter) + 512-sample blocks for the VAD
            val block = FloatArray(512)
            var blockN = 0
            var acc = 0.0
            var cnt = 0
            var inIdx = 0L
            var outIdx = 0L
            fun emit(v: Float) {
                block[blockN++] = v
                if (blockN == 512) {
                    vad.acceptWaveform(block)
                    blockN = 0
                    drain()
                }
            }

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            var lastPct = -1
            while (!outputDone) {
                if (isCancelled()) throw Cancelled()
                if (!inputDone) {
                    val ii = dec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val oi = dec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val out = dec.getOutputBuffer(oi)!!
                    out.position(info.offset)
                    out.limit(info.offset + info.size)
                    val sb = out.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val ratio = srcRate / 16000.0
                    val frames = sb.remaining() / channels
                    for (f in 0 until frames) {
                        var sum = 0f
                        for (c in 0 until channels) sum += sb.get() / 32768f
                        acc += sum / channels
                        cnt++
                        inIdx++
                        if (inIdx >= (outIdx + 1) * ratio) {
                            emit((acc / cnt).toFloat())
                            acc = 0.0
                            cnt = 0
                            outIdx++
                        }
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    if (durationUs > 0) {
                        val pct = (info.presentationTimeUs * 100 / durationUs).toInt().coerceIn(0, 99)
                        if (pct != lastPct) {
                            lastPct = pct
                            onProgress(pct)
                        }
                    }
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    srcRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    inIdx = 0
                    outIdx = 0
                    acc = 0.0
                    cnt = 0
                }
            }
            while (blockN != 0) emit(0f) // pad the last block with silence
            vad.flush()
            drain()
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            extractor.release()
            vad.release()
            recognizer.release()
        }

        if (lines.isEmpty()) throw Exception("No speech found")
        val sb = StringBuilder()
        lines.forEachIndexed { i, l ->
            sb.append(i + 1).append('\n')
            sb.append(ts(l.start)).append(" --> ").append(ts(l.end)).append('\n')
            sb.append(wrap(l.text)).append("\n\n")
        }
        val out = cacheFile(ctx, uri)
        out.parentFile!!.mkdirs()
        out.writeText(sb.toString(), Charsets.UTF_8)
        onProgress(100)
        return out
    }

    private fun ts(t: Float): String {
        val ms = (t * 1000).toLong()
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)
    }

    /** At most two lines of about 42 characters. */
    private fun wrap(text: String): String {
        if (text.length <= 42) return text
        val mid = text.length / 2
        var best = -1
        for (i in text.indices) {
            if (text[i] == ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i
        }
        return if (best < 0) text else text.substring(0, best) + "\n" + text.substring(best + 1)
    }
}
