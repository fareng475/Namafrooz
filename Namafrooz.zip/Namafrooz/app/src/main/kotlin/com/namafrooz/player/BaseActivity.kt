package com.namafrooz.player

import androidx.core.view.WindowInsetsCompat
import androidx.core.view.ViewCompat
import android.view.View
import android.content.res.Configuration
import android.os.Bundle
import android.util.TypedValue
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat

/** Applies the user's accent color and keeps system bar icons readable in light/dark mode. */
open class BaseActivity : AppCompatActivity() {

    private var appliedAccent = ""

    /** Screens that draw their own full-screen UI (the player) turn this off. */
    protected open val applyWindowInsets: Boolean get() = true

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        if (applyWindowInsets) {
            val root = findViewById<View>(android.R.id.content)
            ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
                val b = insets.getInsets(
                    WindowInsetsCompat.Type.systemBars() or
                        WindowInsetsCompat.Type.displayCutout() or
                        WindowInsetsCompat.Type.ime()
                )
                v.setPadding(b.left, b.top, b.right, b.bottom)
                WindowInsetsCompat.CONSUMED
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        appliedAccent = Prefs.accent
        theme.applyStyle(Prefs.accentStyle(), true)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = !night
            isAppearanceLightNavigationBars = !night
        }
    }

    override fun onResume() {
        super.onResume()
        if (appliedAccent != Prefs.accent) recreate()
    }

    fun themeColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }
}
