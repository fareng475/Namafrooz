package com.namafrooz.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatTextView
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Reads and parses subtitle files (SRT, VTT, ASS/SSA) without depending on the video engine. */
object SubtitleParser {
    class Line(val start: Long, val end: Long, val text: String)

    fun readText(ctx: Context, uri: Uri): String {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw Exception("Cannot open the file")
        if (bytes.isEmpty()) throw Exception("The file is empty")
        if (bytes.size >= 2) {
            val b0 = bytes[0].toInt() and 0xFF
            val b1 = bytes[1].toInt() and 0xFF
            if (b0 == 0xFF && b1 == 0xFE) return String(bytes, Charsets.UTF_16LE).removePrefix("\uFEFF")
            if (b0 == 0xFE && b1 == 0xFF) return String(bytes, Charsets.UTF_16BE).removePrefix("\uFEFF")
        }
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        val text = try {
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            String(bytes, charset("windows-1256")) // old Persian / Arabic files
        }
        return text.removePrefix("\uFEFF")
    }

    fun parse(raw: String, fileName: String): List<Line> {
        val text = raw.replace("\r\n", "\n").replace('\r', '\n')
        val ext = fileName.substringAfterLast('.', "").lowercase()
        val out = if (ext == "ass" || ext == "ssa" || text.contains("[Events]")) parseAss(text) else parseSrtVtt(text)
        return out.sortedBy { it.start }
    }

    private val timeRe = Regex("""(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})""")
    private val assTimeRe = Regex("""(\d+):(\d{2}):(\d{2})[.](\d{1,3})""")
    private val blockSplit = Regex("\n\\s*\n")
    private val htmlTag = Regex("<[^>]*>")
    private val assTag = Regex("\\{[^}]*\\}")

    private fun frac(s: String): Long = (s + "00").substring(0, 3).toLong()

    private fun toMs(t: String): Long? {
        val m = timeRe.find(t.trim()) ?: return null
        val h = m.groupValues[1].ifEmpty { "0" }.toLong()
        val mi = m.groupValues[2].toLong()
        val s = m.groupValues[3].toLong()
        return ((h * 60 + mi) * 60 + s) * 1000 + frac(m.groupValues[4])
    }

    private fun clean(body: String): String {
        return body.replace(htmlTag, "").replace(assTag, "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .split('\n').joinToString("\n") { it.trim() }.trim()
    }

    private fun parseSrtVtt(text: String): List<Line> {
        val res = ArrayList<Line>()
        for (block in text.split(blockSplit)) {
            val lines = block.trim().split('\n')
            val ti = lines.indexOfFirst { it.contains("-->") }
            if (ti < 0) continue
            val parts = lines[ti].split("-->")
            if (parts.size < 2) continue
            val s = toMs(parts[0]) ?: continue
            val e = toMs(parts[1]) ?: continue
            val c = clean(lines.drop(ti + 1).joinToString("\n"))
            if (c.isNotBlank()) res.add(Line(s, e, c))
        }
        return res
    }

    private fun assTime(t: String): Long? {
        val m = assTimeRe.find(t.trim()) ?: return null
        val h = m.groupValues[1].toLong()
        val mi = m.groupValues[2].toLong()
        val s = m.groupValues[3].toLong()
        return ((h * 60 + mi) * 60 + s) * 1000 + frac(m.groupValues[4])
    }

    private fun parseAss(text: String): List<Line> {
        val res = ArrayList<Line>()
        var iStart = 1
        var iEnd = 2
        var iText = 9
        var n = 10
        var inEvents = false
        for (raw in text.split('\n')) {
            val line = raw.trim()
            if (line.startsWith("[")) {
                inEvents = line.equals("[Events]", ignoreCase = true)
                continue
            }
            if (!inEvents) continue
            if (line.startsWith("Format:", ignoreCase = true)) {
                val cols = line.substringAfter(':').split(',').map { it.trim().lowercase() }
                n = cols.size
                iStart = cols.indexOf("start").takeIf { it >= 0 } ?: 1
                iEnd = cols.indexOf("end").takeIf { it >= 0 } ?: 2
                iText = cols.indexOf("text").takeIf { it >= 0 } ?: (n - 1)
            } else if (line.startsWith("Dialogue:", ignoreCase = true)) {
                val f = line.substringAfter(':').trimStart().split(',', limit = n)
                if (f.size <= iText) continue
                val s = assTime(f[iStart]) ?: continue
                val e = assTime(f[iEnd]) ?: continue
                val body = f[iText].replace("\\N", "\n").replace("\\n", "\n").replace("\\h", " ")
                val c = clean(body)
                if (c.isNotBlank()) res.add(Line(s, e, c))
            }
        }
        return res
    }
}

/** Text with a dark halo so it stays readable on any picture. */
class OutlineTextView(ctx: Context) : AppCompatTextView(ctx) {
    var outline = true
    override fun onDraw(canvas: Canvas) {
        if (outline) {
            repeat(3) { super.onDraw(canvas) }
        } else {
            super.onDraw(canvas)
        }
    }
}

/** Draws external subtitles over the video; follows the look chosen in the settings. */
class SubtitleOverlay(ctx: Context) : FrameLayout(ctx) {
    private val tv = OutlineTextView(ctx)
    private var cues: List<SubtitleParser.Line> = emptyList()
    private var shown = ""
    var active = true
    var preview: String? = null

    init {
        isClickable = false
        isFocusable = false
        tv.gravity = Gravity.CENTER
        tv.textAlignment = View.TEXT_ALIGNMENT_CENTER
        tv.textDirection = View.TEXT_DIRECTION_ANY_RTL
        tv.visibility = View.GONE
        addView(tv, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }

    fun hasCues() = cues.isNotEmpty()

    fun setCues(list: List<SubtitleParser.Line>) {
        cues = list
        shown = "?"
        update(0)
    }

    fun update(posMs: Long) {
        val text = preview ?: if (active) activeText(posMs) else ""
        if (text == shown) return
        shown = text
        if (text.isEmpty()) {
            tv.visibility = View.GONE
        } else {
            tv.text = text
            tv.visibility = View.VISIBLE
        }
    }

    private fun activeText(t: Long): String {
        if (cues.isEmpty()) return ""
        var lo = 0
        var hi = cues.size - 1
        var idx = -1
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            if (cues[mid].start <= t) {
                idx = mid
                lo = mid + 1
            } else hi = mid - 1
        }
        if (idx < 0) return ""
        val sb = StringBuilder()
        var i = idx
        var count = 0
        while (i >= 0 && count < 4 && idx - i < 8) {
            val c = cues[i]
            if (c.end > t) {
                if (sb.isNotEmpty()) sb.insert(0, "\n")
                sb.insert(0, c.text)
                count++
            }
            i--
        }
        return sb.toString()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyStyle()
    }

    private var fl = 0
    private var ft = 0
    private var fr = 0
    private var fb = 0
    private var hasFrame = false

    /** The rectangle the video really occupies (in this view's pixels). */
    fun setFrame(l: Int, t: Int, r: Int, b: Int) {
        if (hasFrame && l == fl && t == ft && r == fr && b == fb) return
        hasFrame = true
        fl = l; ft = t; fr = r; fb = b
        applyStyle()
    }

    fun applyStyle() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        val d = resources.displayMetrics.density
        // text size depends on the SHORT side of the screen, so it looks the same upright and sideways
        val px = minOf(w, h) * 0.055f * (Prefs.subScale / 100f)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
        val colors = intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4DD0E1.toInt(), 0xFF69F0AE.toInt())
        tv.setTextColor(colors[Prefs.subColor.coerceIn(0, 3)])
        tv.setTypeface(if (Prefs.subBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT)
        val boxColor = when (Prefs.subBg) {
            1 -> 0x80000000.toInt()
            2 -> 0xCC000000.toInt()
            else -> 0
        }
        if (boxColor != 0) {
            val g = GradientDrawable()
            g.cornerRadius = 8 * d
            g.setColor(boxColor)
            tv.background = g
            tv.setPadding((10 * d).toInt(), (3 * d).toInt(), (10 * d).toInt(), (3 * d).toInt())
            tv.outline = false
            tv.setShadowLayer(0f, 0f, 0f, 0)
        } else {
            tv.background = null
            tv.setPadding(0, 0, 0, 0)
            tv.outline = true
            tv.setShadowLayer(px / 6f, 0f, 0f, Color.BLACK)
        }
        // keep the text inside the picture and put it near the picture's bottom edge
        val left = if (hasFrame) fl.coerceIn(0, w) else 0
        val right = if (hasFrame) fr.coerceIn(left, w) else w
        val bottomEdge = if (hasFrame) fb.coerceIn(0, h) else h
        val top = if (hasFrame) ft.coerceIn(0, bottomEdge) else 0
        val frameW = (right - left).coerceAtLeast(1)
        val frameH = (bottomEdge - top).coerceAtLeast(1)
        val frac = when (Prefs.subPos) {
            0 -> 0.03f
            2 -> 0.16f
            else -> 0.08f
        }
        tv.maxWidth = (frameW * 0.94f).toInt()
        val lp = tv.layoutParams as LayoutParams
        lp.bottomMargin = (h - bottomEdge) + (frameH * frac).toInt()
        lp.leftMargin = left
        lp.rightMargin = w - right
        tv.layoutParams = lp
    }
}
