package com.namafrooz.player

import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultDataSource
import java.io.File
import androidx.core.app.ActivityCompat
import android.provider.MediaStore
import android.os.Environment
import android.Manifest
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.common.text.Cue
import android.graphics.Typeface
import android.widget.FrameLayout
import android.view.Gravity
import android.util.Rational
import android.content.res.Configuration
import android.content.pm.PackageManager
import android.app.PictureInPictureParams
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.media.AudioManager
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

@UnstableApi
class PlayerActivity : BaseActivity() {

    override val applyWindowInsets: Boolean get() = false

    private lateinit var lockLayer: FrameLayout
    private lateinit var unlockBtn: ImageButton
    private var locked = false
    private var extraAudioKey: String? = null
    private var originalItem: MediaItem? = null
    private var seekStart = 0L
    private var seekTarget = 0L

    // external subtitles (our own engine) + the loop that keeps them in time with the video
    private lateinit var extSub: SubtitleOverlay
    private var extName: String? = null
    private var subKey = ""
    private val subTick = object : Runnable {
        override fun run() {
            if (::extSub.isInitialized && ::player.isInitialized) {
                if (::contentFrame.isInitialized) {
                    extSub.setFrame(
                        pv.left + contentFrame.left, pv.top + contentFrame.top,
                        pv.left + contentFrame.right, pv.top + contentFrame.bottom
                    )
                }
                extSub.update(player.currentPosition - SyncState.subDelayMs)
            }
            handler.postDelayed(this, 100)
        }
    }
    private val hideUnlock = Runnable { if (::unlockBtn.isInitialized) unlockBtn.visibility = View.GONE }

    private lateinit var player: ExoPlayer
    private lateinit var pv: PlayerView
    private lateinit var topBar: View
    private lateinit var tvSpeed: TextView
    private lateinit var tvLeft: TextView
    private lateinit var tvRight: TextView
    private lateinit var tvInfo: TextView
    private lateinit var syncPanel: View
    private lateinit var tvSyncTitle: TextView
    private lateinit var tvSyncValue: TextView
    private var syncMode = -1 // 0 = subtitle, 1 = audio

    private val handler = Handler(Looper.getMainLooper())

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var speedActive = false
    private var prevSpeed = 1f
    private var lastTapTime = 0L
    private var pendingToggle: Runnable? = null
    private var acc = 0
    private var accForward = true

    // swipe (volume / brightness) state
    private var gestureMode = 0 // 0 = undecided, 1 = brightness, 2 = volume, -1 = ignore
    private var startBright = 0.5f
    private var startVol = 0f // volume level in percent when the finger went down

    // orientation + zoom
    private var portrait = false
    private var zoom = 1f
    private var panX = 0f
    private var panY = 0f
    private var lastFx = 0f
    private var lastFy = 0f
    private var panValid = false
    private var multiTouch = false
    private lateinit var contentFrame: View
    private lateinit var scaleDetector: ScaleGestureDetector
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private val subLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }

    // resume protection: never overwrite a good saved position with ~0 while the start seek is settling
    private var resumeTarget = 0L
    private var resumeKey = ""
    private var resumeGuardUntil = 0L

    private val saver = object : Runnable {
        override fun run() {
            savePosition()
            handler.postDelayed(this, 3000)
        }
    }

    private val longPress = Runnable {
        speedActive = true
        prevSpeed = player.playbackParameters.speed
        player.setPlaybackSpeed(Prefs.holdSpeed)
        tvSpeed.text = "▶▶  ${Prefs.holdSpeed}x"
        tvSpeed.visibility = View.VISIBLE
        pv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private val hideSync = Runnable {
        syncPanel.visibility = View.GONE
        syncMode = -1
    }

    private val applySync = Runnable {
        if (::player.isInitialized) player.seekTo(player.currentPosition)
    }

    private val hideInfo = Runnable { tvInfo.visibility = View.GONE }

    private val hideSeek = Runnable {
        tvLeft.visibility = View.GONE
        tvRight.visibility = View.GONE
        acc = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        goFullscreen()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        pv = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvLeft = findViewById(R.id.tvLeft)
        tvRight = findViewById(R.id.tvRight)
        tvInfo = findViewById(R.id.tvInfo)
        syncPanel = findViewById(R.id.syncPanel)
        tvSyncTitle = findViewById(R.id.tvSyncTitle)
        tvSyncValue = findViewById(R.id.tvSyncValue)
        SyncState.subDelayMs = 0
        SyncState.audioDelayMs = 0

        val queue: List<Video>
        val start: Int
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) {
            queue = listOf(Video(0, data, displayName(data), 0, "", 0))
            start = 0
        } else {
            queue = PlaybackQueue.items
            start = PlaybackQueue.start
        }
        if (queue.isEmpty()) { finish(); return }

        val seekMs = Prefs.seekSeconds * 1000L
        player = ExoPlayer.Builder(this, SyncRenderersFactory(this))
            .setSeekBackIncrementMs(seekMs)
            .setSeekForwardIncrementMs(seekMs)
            .build()
        pv.player = player
        contentFrame = pv.findViewById(androidx.media3.ui.R.id.exo_content_frame)
        addRotateButton()
        addExtraButtons()
        setupLock()
        setupExternalSubtitles()
        setupPanel()
        applyFit()
        // Skipping is done only with double-tap; subtitle choice lives in the settings menu.
        pv.setShowRewindButton(false)
        pv.setShowFastForwardButton(false)
        pv.setShowSubtitleButton(false)
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { showSettingsMenu() }
        applySubtitleStyle()
        applyTimeBarColors()
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
            if (vis != View.VISIBLE) hideSync.run()
        })

        val items = queue.map {
            MediaItem.Builder().setUri(it.uri).setMediaId(it.uri.toString()).build()
        }
        val key = queue[start].uri.toString()
        val saved = Prefs.pos(key)
        val d = Prefs.dur(key)
        val startPos = if (Prefs.resume && saved > 3000 && (d <= 0 || saved < d - 8000)) saved else 0L
        resumeTarget = startPos
        resumeKey = key
        if (startPos > 0) resumeGuardUntil = SystemClock.elapsedRealtime() + 15000
        player.setMediaItems(items, start, startPos)
        player.setPauseAtEndOfMediaItems(!Prefs.autoNext)
        player.prepare()
        autoLoadSubtitle()
        player.playWhenReady = true

        // some files ignore the start position; seek again once the player is ready
        if (startPos > 0) {
            player.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == androidx.media3.common.Player.STATE_READY) {
                        player.removeListener(this)
                        if (kotlin.math.abs(player.currentPosition - startPos) > 3000) {
                            player.seekTo(player.currentMediaItemIndex, startPos)
                        }
                    }
                }
            })
        }

        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying) savePosition()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                autoLoadSubtitle()
            }

            override fun onPlayerError(error: PlaybackException) {
                CrashLog.add(applicationContext, "Player error", error)
                Toast.makeText(
                    this@PlayerActivity,
                    getString(R.string.play_error, error.errorCodeName),
                    Toast.LENGTH_LONG
                ).show()
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    val id = oldPosition.mediaItem?.mediaId ?: return
                    val dur = Prefs.dur(id)
                    if (dur > 0) Prefs.savePos(id, dur, dur)
                } else {
                    savePosition()
                }
            }
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSubSync).setOnClickListener { openSync(0) }
        findViewById<View>(R.id.btnAudioSync).setOnClickListener { openSync(1) }
        fun step(id: Int, d: Int) = findViewById<View>(id).setOnClickListener { setDelay(currentDelay() + d) }
        step(R.id.btnSyncM5, -500)
        step(R.id.btnSyncM1, -100)
        step(R.id.btnSyncP1, 100)
        step(R.id.btnSyncP5, 500)
        findViewById<View>(R.id.btnSyncReset).setOnClickListener { setDelay(0) }
        setupGestures()
    }

    // ---------- orientation + zoom ----------

    private fun addRotateButton() {
        val basic = pv.findViewById<ViewGroup>(androidx.media3.ui.R.id.exo_basic_controls) ?: return
        val settingsBtn = pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)
        val size = (48 * resources.displayMetrics.density).toInt()
        val pad = (12 * resources.displayMetrics.density).toInt()
        val btn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_rotate)
            background = null
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
            contentDescription = getString(R.string.rotate_screen)
            layoutParams = LinearLayout.LayoutParams(size, size)
            setOnClickListener { toggleOrientation() }
        }
        val idx = basic.indexOfChild(settingsBtn)
        if (idx >= 0) basic.addView(btn, idx) else basic.addView(btn)
    }

    private fun toggleOrientation() {
        portrait = !portrait
        requestedOrientation = if (portrait) ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        else ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        zoom = 1f; panX = 0f; panY = 0f
        applyZoom()
    }

    private fun setZoom(z: Float) {
        zoom = z.coerceIn(0.5f, 4f)
        clampPan()
        applyZoom()
        showInfo(Loc.digits(this, "${(zoom * 100).roundToInt()}%"))
    }

    private fun clampPan() {
        val mx = kotlin.math.max(0f, contentFrame.width * (zoom - 1f) / 2f)
        val my = kotlin.math.max(0f, contentFrame.height * (zoom - 1f) / 2f)
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
    }

    private fun applyZoom() {
        contentFrame.scaleX = zoom
        contentFrame.scaleY = zoom
        contentFrame.translationX = panX
        contentFrame.translationY = panY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        scaleDetector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScaleBegin(detector: ScaleGestureDetector): Boolean = Prefs.pinchZoom
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                setZoom(zoom * detector.scaleFactor)
                return true
            }

            override fun onScaleEnd(detector: ScaleGestureDetector) {
                // snap back to exactly 100% when close
                if (abs(zoom - 1f) < 0.06f) {
                    zoom = 1f; panX = 0f; panY = 0f
                    applyZoom()
                    showInfo(Loc.digits(this@PlayerActivity, "100%"))
                }
            }
        })
        scaleDetector.isQuickScaleEnabled = false
        pv.setOnTouchListener { v, e ->
            if (Prefs.pinchZoom) scaleDetector.onTouchEvent(e)
            if (e.pointerCount > 1) {
                // two fingers: zoom / pan only, never tap or swipe gestures
                multiTouch = true
                handler.removeCallbacks(longPress)
                gestureMode = -1
                if (speedActive) endSpeed()
                if (Prefs.pinchZoom && e.pointerCount == 2 && e.actionMasked == MotionEvent.ACTION_MOVE) {
                    val fx = (e.getX(0) + e.getX(1)) / 2f
                    val fy = (e.getY(0) + e.getY(1)) / 2f
                    if (panValid && zoom > 1f) {
                        panX += fx - lastFx
                        panY += fy - lastFy
                        clampPan()
                        applyZoom()
                    }
                    lastFx = fx; lastFy = fy; panValid = true
                } else if (e.actionMasked != MotionEvent.ACTION_MOVE) {
                    panValid = false
                }
                return@setOnTouchListener true
            }
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y; moved = false
                    multiTouch = false
                    panValid = false
                    gestureMode = 0
                    val mx = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC) * player.volume / mx * 100f
                    startBright = currentBrightness()
                    if (e.x > v.width / 2f) handler.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (hypot(dx, dy) > slop) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved && !speedActive) {
                        if (gestureMode == 0) {
                            gestureMode = if (abs(dy) > abs(dx)) {
                                if (!Prefs.swipe) -1 else if (downX < v.width / 2f) 1 else 2
                            } else if (Prefs.swipeSeek && player.duration > 0) {
                                seekStart = player.currentPosition
                                seekTarget = seekStart
                                3
                            } else -1
                        }
                        if (gestureMode == 1 || gestureMode == 2) adjust(gestureMode, -dy / v.height)
                        if (gestureMode == 3) seekPreview(dx / v.width)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) {
                        endSpeed()
                    } else if (gestureMode == 3) {
                        player.seekTo(seekTarget)
                        gestureMode = 0
                    } else if (!moved && !multiTouch) {
                        onTap(e.x > v.width / 2f)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) endSpeed()
                }
            }
            true
        }
    }

    /** Horizontal swipe: right = forward, left = back. A full-width swipe moves about 1/6 of the video (1 to 5 minutes). */
    private fun seekPreview(frac: Float) {
        val dur = player.duration
        if (dur <= 0) return
        val span = (dur / 6).coerceIn(60_000L, 300_000L)
        val target = (seekStart + (frac * span).toLong()).coerceIn(0L, dur)
        seekTarget = target
        val delta = target - seekStart
        val sign = if (delta >= 0) "+" else "−"
        showInfo(Loc.digits(this, sign + formatTime(abs(delta)) + "  /  " + formatTime(target)))
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) {
            0.5f
        }
    }

    private fun adjust(mode: Int, ratio: Float) {
        if (mode == 1) {
            val b = (startBright + ratio * 1.2f).coerceIn(0.02f, 1f)
            val lp = window.attributes
            lp.screenBrightness = b
            window.attributes = lp
            showInfo(Loc.digits(this, "${(b * 100).roundToInt()}%"), R.drawable.ic_sun)
        } else {
            // 1% steps: the system volume gives the coarse level, the player gain adds the fine part
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val level = (startVol + ratio * 100f * 1.2f).coerceIn(0f, 100f).roundToInt()
            val target = level / 100f * max
            val idx = kotlin.math.ceil(target.toDouble()).toInt().coerceIn(0, max)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, idx, 0)
            player.volume = if (idx == 0) 0f else (target / idx).coerceIn(0f, 1f)
            showInfo(Loc.digits(this, "$level%"), R.drawable.ic_volume_art)
        }
    }

    private fun showInfo(text: String, iconRes: Int = 0) {
        tvInfo.text = text
        if (iconRes != 0) {
            val d = ContextCompat.getDrawable(this, iconRes)!!.mutate()
            val density = resources.displayMetrics.density
            val h = (18 * density).toInt()
            val w = h * d.intrinsicWidth / d.intrinsicHeight.coerceAtLeast(1)
            d.setBounds(0, 0, w, h)
            tvInfo.setCompoundDrawablesRelative(d, null, null, null)
            tvInfo.compoundDrawablePadding = (8 * density).toInt()
        } else {
            tvInfo.setCompoundDrawablesRelative(null, null, null, null)
        }
        tvInfo.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, 800)
    }

    private fun applySubtitleStyle() {
        val scale = Prefs.subScale / 100f
        val vw = pv.width
        val vh = pv.height
        val size = if (vw > 0 && vh > 0) 0.055f * scale * minOf(vw, vh) / vh else 0.055f * scale
        val sv = pv.subtitleView ?: return
        sv.setApplyEmbeddedStyles(false)
        sv.setApplyEmbeddedFontSizes(false)
        sv.setFractionalTextSize(size)
        sv.setBottomPaddingFraction(
            when (Prefs.subPos) {
                0 -> 0.03f
                2 -> 0.16f
                else -> 0.08f
            }
        )
        val colors = intArrayOf(Color.WHITE, 0xFFFFEB3B.toInt(), 0xFF4DD0E1.toInt(), 0xFF69F0AE.toInt())
        val fg = colors[Prefs.subColor.coerceIn(0, 3)]
        val bg = when (Prefs.subBg) {
            1 -> 0x80000000.toInt()
            2 -> 0xCC000000.toInt()
            else -> Color.TRANSPARENT
        }
        val edge = if (Prefs.subBg == 0) CaptionStyleCompat.EDGE_TYPE_OUTLINE else CaptionStyleCompat.EDGE_TYPE_NONE
        val face = if (Prefs.subBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        sv.setStyle(CaptionStyleCompat(fg, bg, Color.TRANSPARENT, edge, Color.BLACK, face))
        if (::extSub.isInitialized) extSub.applyStyle()
    }

    private fun applyFit() {
        pv.resizeMode = when (Prefs.fitMode) {
            1 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            2 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }
    }

    private fun applyTimeBarColors() {
        val bar = pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? DefaultTimeBar ?: return
        val accent = themeColor(R.attr.appAccent)
        bar.setPlayedColor(accent)
        bar.setScrubberColor(accent)
        bar.setBufferedColor((accent and 0x00FFFFFF) or 0x66000000)
        bar.setUnplayedColor(0x33FFFFFF)
    }

    private fun endSpeed() {
        speedActive = false
        player.setPlaybackSpeed(prevSpeed)
        tvSpeed.visibility = View.GONE
    }

    private fun onTap(right: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (now - lastTapTime < 400) {
            pendingToggle?.let { handler.removeCallbacks(it) }
            pendingToggle = null
            doSeek(right)
        } else {
            val r = Runnable {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
            }
            pendingToggle = r
            handler.postDelayed(r, 400)
        }
        lastTapTime = now
    }

    private fun doSeek(forward: Boolean) {
        val s = Prefs.seekSeconds
        if (forward != accForward) acc = 0
        accForward = forward
        acc += s
        val dur = player.duration
        var t = player.currentPosition + (if (forward) s else -s) * 1000L
        t = t.coerceAtLeast(0L)
        if (dur != C.TIME_UNSET) t = t.coerceAtMost(dur)
        player.seekTo(t)

        val show = if (forward) tvRight else tvLeft
        val hide = if (forward) tvLeft else tvRight
        hide.visibility = View.GONE
        show.text = (if (forward) "+" else "−") + acc + " s"
        show.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeek)
        handler.postDelayed(hideSeek, 700)
    }

    /** Loads a subtitle file (SRT / VTT / ASS) and shows it over the video. */
    private fun addSubtitle(srcUri: Uri, silent: Boolean = false): Boolean {
        val name = displayName(srcUri)
        return try {
            val lines = SubtitleParser.parse(SubtitleParser.readText(this, srcUri), name)
            if (lines.isEmpty()) throw Exception(getString(R.string.sub_no_lines))
            extSub.setCues(lines)
            extSub.active = true
            extName = name
            // the file replaces any built-in subtitle so nothing is drawn twice
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            val key = player.currentMediaItem?.mediaId
            if (key != null && srcUri.scheme == "file") Prefs.setSubFile(key, srcUri.path ?: "")
            extSub.update(player.currentPosition - SyncState.subDelayMs)
            if (!silent) Toast.makeText(this, getString(R.string.sub_loaded, name, lines.size), Toast.LENGTH_LONG).show()
            true
        } catch (e: Throwable) {
            CrashLog.add(applicationContext, "Subtitle load failed: " + name, e)
            if (!silent) {
                MaterialAlertDialogBuilder(this)
                    .setMessage(getString(R.string.sub_error, e.message ?: e.javaClass.simpleName))
                    .setPositiveButton(android.R.string.ok, null)
                    .show()
            }
            false
        }
    }

    private fun setupExternalSubtitles() {
        val root = pv.parent as? ViewGroup ?: return
        extSub = SubtitleOverlay(this)
        root.addView(
            extSub, root.indexOfChild(pv) + 1,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        applySubtitleStyle()
        pv.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if ((r - l) != (orr - ol) || (b - t) != (ob - ot)) applySubtitleStyle()
        }
        handler.post(subTick)
    }

    private fun videoDir(): File? {
        val uri = player.currentMediaItem?.localConfiguration?.uri ?: return null
        return try {
            if (uri.scheme == "file") {
                File(uri.path ?: "").parentFile
            } else {
                contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0)?.takeIf { it.isNotEmpty() }?.let { File(it).parentFile } else null
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    /** For every new video: use the subtitle chosen before, or one with the same name next to the video. */
    private fun autoLoadSubtitle() {
        if (!::extSub.isInitialized) return
        val item = player.currentMediaItem ?: return
        if (item.mediaId == subKey) return
        subKey = item.mediaId
        extSub.setCues(emptyList())
        extName = null
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
        val saved = Prefs.subFile(item.mediaId)
        if (saved == "-") return // the user removed the subtitle of this video on purpose
        var f: File? = saved?.let { File(it) }?.takeIf { it.isFile }
        if (f == null) f = findSiblingSubtitle(item)
        if (f != null) addSubtitle(Uri.fromFile(f), true)
    }

    private fun findSiblingSubtitle(item: MediaItem): File? {
        val uri = item.localConfiguration?.uri ?: return null
        return try {
            val dir = videoDir() ?: return null
            val base = displayName(uri).substringBeforeLast('.').lowercase()
            val exts = setOf("srt", "ass", "ssa", "vtt")
            (dir.listFiles() ?: return null)
                .filter { it.isFile && it.extension.lowercase() in exts }
                .filter {
                    val n = it.nameWithoutExtension.lowercase()
                    n == base || n.startsWith("$base.") || n.startsWith("$base ")
                }
                .minByOrNull { it.name.length }
        } catch (_: Exception) {
            null
        }
    }

    // ---------- sync panel (subtitle / audio delay) ----------

    private fun currentDelay() = if (syncMode == 0) SyncState.subDelayMs else SyncState.audioDelayMs

    private fun openSync(mode: Int) {
        if (syncMode == mode && syncPanel.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideSync)
            hideSync.run()
            return
        }
        syncMode = mode
        tvSyncTitle.setText(if (mode == 0) R.string.sync_subtitle else R.string.sync_audio)
        refreshSync()
        syncPanel.visibility = View.VISIBLE
        scheduleHideSync()
    }

    private fun scheduleHideSync() {
        handler.removeCallbacks(hideSync)
        handler.postDelayed(hideSync, 5000)
        pv.showController()
    }

    private fun setDelay(ms: Int) {
        val v = ms.coerceIn(-10000, 10000)
        if (syncMode == 0) SyncState.subDelayMs = v else SyncState.audioDelayMs = v
        refreshSync()
        scheduleHideSync()
        handler.removeCallbacks(applySync)
        handler.postDelayed(applySync, 300)
    }

    private fun refreshSync() {
        val v = currentDelay()
        val sign = if (v > 0) "+" else if (v < 0) "−" else ""
        val num = String.format(Locale.US, "%.1f", abs(v) / 1000f)
        tvSyncValue.text = Loc.digits(this, getString(R.string.sync_value, sign + num))
    }

    // ---------- settings menu ----------

    private lateinit var panel: PlayerPanel

    private fun setupPanel() {
        val root = pv.parent as? ViewGroup ?: return
        panel = PlayerPanel(this, root, themeColor(R.attr.appAccent), object : PlayerPanel.Actions {
            override fun audioTracks() = showTrackMenu(C.TRACK_TYPE_AUDIO)
            override fun subtitleTracks() = showTrackMenu(C.TRACK_TYPE_TEXT)
            override fun addSubtitleFile() = subLauncher.launch(arrayOf("*/*"))
            override fun currentSpeed(): Float = player.playbackParameters.speed
            override fun setSpeed(s: Float) = player.setPlaybackSpeed(s)
            override fun styleChanged() = applySubtitleStyle()
            override fun fitChanged() = applyFit()
            override fun autoNextChanged() = player.setPauseAtEndOfMediaItems(!Prefs.autoNext)
            override fun syncValue(mode: Int): Int = if (mode == 0) SyncState.subDelayMs else SyncState.audioDelayMs
            override fun syncSet(mode: Int, ms: Int) {
                val v = ms.coerceIn(-10000, 10000)
                if (mode == 0) SyncState.subDelayMs = v else SyncState.audioDelayMs = v
                handler.removeCallbacks(applySync)
                handler.postDelayed(applySync, 300)
            }

            override fun hasFileAccess(): Boolean =
                if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
                else ContextCompat.checkSelfPermission(this@PlayerActivity, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

            override fun requestFileAccess() {
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                    } catch (e: Exception) {
                        startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                    }
                } else {
                    ActivityCompat.requestPermissions(this@PlayerActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 77)
                }
            }

            override fun startDir(): File? =
                videoDir() ?: Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)

            override fun videoBaseName(): String {
                val uri = player.currentMediaItem?.localConfiguration?.uri ?: return ""
                return displayName(uri).substringBeforeLast('.')
            }

            override fun pickSubtitle(file: File) {
                addSubtitle(Uri.fromFile(file))
            }

            override fun pickAudio(file: File) {
                addAudio(Uri.fromFile(file))
            }

            override fun hasExtraAudio(): Boolean =
                extraAudioKey != null && player.currentMediaItem?.mediaId == extraAudioKey

            override fun removeExtraAudio() = removeAudioTrack()
            override fun hasExtraSubtitle(): Boolean = extSub.hasCues()
            override fun removeExtraSubtitle() = removeSubtitleFile()

            override fun previewSubtitle(show: Boolean) {
                val sample = getString(R.string.sub_sample)
                if (extSub.hasCues()) {
                    extSub.preview = if (show) sample else null
                    extSub.update(player.currentPosition - SyncState.subDelayMs)
                    return
                }
                val sv = pv.subtitleView ?: return
                if (show) {
                    sv.setCues(listOf(Cue.Builder().setText(sample).build()))
                } else {
                    sv.setCues(player.currentCues.cues)
                }
            }
        })
    }

    private fun showSettingsMenu() {
        if (::panel.isInitialized) panel.toggle()
    }

    private fun showSpeedMenu() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = speeds.map { Loc.digits(this, "${it}x") }.toTypedArray()
        val cur = speeds.indexOfFirst { it == player.playbackParameters.speed }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.menu_speed)
            .setSingleChoiceItems(labels, cur) { d, i ->
                player.setPlaybackSpeed(speeds[i])
                d.dismiss()
            }
            .show()
    }

    private fun trackLabel(f: Format, n: Int): String {
        val lang = f.language?.takeIf { it != "und" }
            ?.let { Locale.forLanguageTag(it).displayLanguage }
            ?.takeIf { it.isNotBlank() }
        val parts = ArrayList<String>()
        f.label?.let { parts.add(it) }
        lang?.let { parts.add(it) }
        val named = parts.isNotEmpty()
        val mime = f.sampleMimeType ?: ""
        if (mime.startsWith("audio/")) {
            val codec = when (mime) {
                MimeTypes.AUDIO_AAC -> "AAC"
                MimeTypes.AUDIO_AC3 -> "AC3"
                MimeTypes.AUDIO_E_AC3 -> "E-AC3"
                MimeTypes.AUDIO_OPUS -> "Opus"
                MimeTypes.AUDIO_MPEG -> "MP3"
                MimeTypes.AUDIO_DTS -> "DTS"
                MimeTypes.AUDIO_FLAC -> "FLAC"
                MimeTypes.AUDIO_VORBIS -> "Vorbis"
                else -> null
            }
            codec?.let { parts.add(it) }
            when (f.channelCount) {
                1 -> parts.add("Mono")
                2 -> parts.add("Stereo")
                6 -> parts.add("5.1")
                8 -> parts.add("7.1")
            }
        }
        val text = parts.distinct().joinToString(" · ")
        return if (!named) {
            getString(R.string.track_n, n) + if (text.isNotEmpty()) " · $text" else ""
        } else text
    }

    private fun showTrackMenu(type: Int) {
        val isText = type == C.TRACK_TYPE_TEXT
        val entries = ArrayList<Triple<Tracks.Group, Int, String>>()
        for (g in player.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Triple(g, i, trackLabel(g.getTrackFormat(i), entries.size + 1)))
            }
        }
        val hasExt = isText && extSub.hasCues()
        if (entries.isEmpty() && !hasExt) {
            Toast.makeText(this, R.string.no_tracks, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ArrayList<String>()
        if (isText) labels.add(getString(R.string.sub_off))
        if (hasExt) labels.add(getString(R.string.sub_file_item, extName ?: ""))
        entries.forEach { labels.add(it.third) }
        val shift = (if (isText) 1 else 0) + (if (hasExt) 1 else 0)
        var checked = -1
        val textOff = isText && player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
        if (hasExt && extSub.active) {
            checked = 1
        } else if (textOff) {
            checked = 0
        } else {
            entries.forEachIndexed { idx, e -> if (e.first.isTrackSelected(e.second)) checked = idx + shift }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(if (isText) R.string.menu_subtitle else R.string.menu_audio)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val b = player.trackSelectionParameters.buildUpon()
                if (isText && which == 0) {
                    extSub.active = false
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else if (hasExt && which == 1) {
                    extSub.active = true
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else {
                    val e = entries[which - shift]
                    if (isText) extSub.active = false
                    b.setTrackTypeDisabled(type, false)
                        .setOverrideForType(TrackSelectionOverride(e.first.mediaTrackGroup, e.second))
                }
                player.trackSelectionParameters = b.build()
                extSub.update(player.currentPosition - SyncState.subDelayMs)
                d.dismiss()
            }
            .show()
    }

    /** Plays an extra audio file together with the current video and switches to it. */
    private fun addAudio(uri: Uri) {
        val cur = player.currentMediaItem ?: return
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        try {
            val video = DefaultMediaSourceFactory(this).createMediaSource(cur)
            val audio = ProgressiveMediaSource.Factory(DefaultDataSource.Factory(this))
                .createMediaSource(MediaItem.fromUri(uri))
            player.addMediaSource(idx + 1, MergingMediaSource(video, audio))
            player.removeMediaItem(idx)
            player.seekTo(idx, pos)
            player.playWhenReady = true
            originalItem = cur
            extraAudioKey = cur.mediaId
            player.addListener(object : androidx.media3.common.Player.Listener {
                override fun onTracksChanged(tracks: Tracks) {
                    val groups = tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
                    if (groups.size >= 2) {
                        val g = groups.last()
                        if (g.length > 0 && g.isTrackSupported(0)) {
                            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                                .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0))
                                .build()
                        }
                        player.removeListener(this)
                    }
                }
            })
        } catch (e: Throwable) {
            CrashLog.add(applicationContext, "Adding audio failed", e)
            MaterialAlertDialogBuilder(this)
                .setMessage(getString(R.string.audio_error, e.message ?: e.javaClass.simpleName))
                .setPositiveButton(android.R.string.ok, null)
                .show()
        }
    }

    /** Puts the plain video back, without the extra audio file. The original sound stays. */
    private fun removeAudioTrack() {
        val orig = originalItem ?: return
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        try {
            player.addMediaItem(idx + 1, orig)
            player.removeMediaItem(idx)
            player.seekTo(idx, pos)
            player.playWhenReady = true
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .clearOverridesOfType(C.TRACK_TYPE_AUDIO)
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, false)
                .build()
            extraAudioKey = null
            originalItem = null
        } catch (e: Throwable) {
            CrashLog.add(applicationContext, "Removing audio failed", e)
        }
    }

    /** Removes the subtitle file the user added; it will not load again for this video. */
    private fun removeSubtitleFile() {
        extSub.setCues(emptyList())
        extName = null
        player.currentMediaItem?.mediaId?.let { Prefs.setSubFile(it, "-") }
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "video"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) name = c.getString(i)
            }
        } catch (_: Exception) {
        }
        return name
    }

    private fun savePosition() {
        if (!::player.isInitialized) return
        val item = player.currentMediaItem ?: return
        val d = player.duration
        val pos = player.currentPosition
        if (resumeTarget > 0 && SystemClock.elapsedRealtime() < resumeGuardUntil &&
            item.mediaId == resumeKey && pos < resumeTarget - 3000
        ) return
        if (d != C.TIME_UNSET && d > 0) {
            Prefs.savePos(item.mediaId, pos, d)
            Prefs.lastKey = item.mediaId
        }
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onResume() {
        super.onResume()
        if (::panel.isInitialized) panel.refresh()
    }

    override fun onStart() {
        super.onStart()
        handler.post(saver)
    }

    // ---------- lock screen + picture-in-picture ----------

    private fun addExtraButtons() {
        val basic = pv.findViewById<ViewGroup>(androidx.media3.ui.R.id.exo_basic_controls) ?: return
        val settingsBtn = pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)
        val d = resources.displayMetrics.density
        val size = (48 * d).toInt()
        val pad = (12 * d).toInt()
        fun make(icon: Int, desc: Int, click: () -> Unit): ImageButton = ImageButton(this).apply {
            setImageResource(icon)
            background = null
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
            contentDescription = getString(desc)
            layoutParams = LinearLayout.LayoutParams(size, size)
            setOnClickListener { click() }
        }
        val buttons = listOf(
            make(R.drawable.ic_lock, R.string.lock_screen) { setLocked(true) },
            make(R.drawable.ic_pip, R.string.pip) { enterPip() }
        )
        for (b in buttons) {
            val idx = basic.indexOfChild(settingsBtn)
            if (idx >= 0) basic.addView(b, idx) else basic.addView(b)
        }
    }

    private fun setupLock() {
        val root = pv.parent as? ViewGroup ?: return
        val d = resources.displayMetrics.density
        lockLayer = FrameLayout(this)
        lockLayer.isClickable = true
        lockLayer.visibility = View.GONE
        unlockBtn = ImageButton(this)
        unlockBtn.setImageResource(R.drawable.ic_lock)
        unlockBtn.background = ContextCompat.getDrawable(this, R.drawable.bg_ghost)
        val pad = (14 * d).toInt()
        unlockBtn.setPadding(pad, pad, pad, pad)
        unlockBtn.contentDescription = getString(R.string.unlock_screen)
        unlockBtn.visibility = View.GONE
        val lp = FrameLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt(), Gravity.CENTER_VERTICAL or Gravity.START)
        lp.marginStart = (28 * d).toInt()
        unlockBtn.layoutParams = lp
        unlockBtn.setOnClickListener { setLocked(false) }
        lockLayer.setOnClickListener {
            unlockBtn.visibility = View.VISIBLE
            handler.removeCallbacks(hideUnlock)
            handler.postDelayed(hideUnlock, 2500)
        }
        lockLayer.addView(unlockBtn)
        root.addView(lockLayer, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun setLocked(on: Boolean) {
        locked = on
        lockLayer.visibility = if (on) View.VISIBLE else View.GONE
        if (on) {
            pv.hideController()
            hideSync.run()
        } else {
            unlockBtn.visibility = View.GONE
            pv.showController()
        }
    }

    private fun enterPip() {
        if (Build.VERSION.SDK_INT < 26) return
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return
        val vs = player.videoSize
        val ratio = (if (vs.width > 0 && vs.height > 0) vs.width.toFloat() / vs.height else 16f / 9f).coerceIn(0.43f, 2.3f)
        try {
            enterPictureInPictureMode(
                PictureInPictureParams.Builder()
                    .setAspectRatio(Rational((ratio * 1000).toInt(), 1000))
                    .build()
            )
        } catch (_: Exception) {
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (::player.isInitialized && player.isPlaying && !locked) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        pv.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) {
            if (::panel.isInitialized) panel.hide()
            topBar.visibility = View.GONE
            hideSync.run()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && ::player.isInitialized) {
            player.volume = 1f
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onPause() {
        super.onPause()
        savePosition()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saver)
        savePosition()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (::player.isInitialized) player.release()
    }
}
