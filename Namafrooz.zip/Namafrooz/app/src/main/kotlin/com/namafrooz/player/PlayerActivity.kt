package com.namafrooz.player

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioManager
import android.provider.Settings
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

@UnstableApi
class PlayerActivity : BaseActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var pv: PlayerView
    private lateinit var topBar: View
    private lateinit var tvSpeed: TextView
    private lateinit var tvLeft: TextView
    private lateinit var tvRight: TextView
    private lateinit var tvInfo: TextView
    private lateinit var syncPanel: View
    private lateinit var tvSyncTitle: TextView
    private lateinit var tvSyncValue: TextView
    private var syncMode = -1 // 0 = subtitle, 1 = audio

    private val handler = Handler(Looper.getMainLooper())

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var speedActive = false
    private var prevSpeed = 1f
    private var lastTapTime = 0L
    private var pendingToggle: Runnable? = null
    private var acc = 0
    private var accForward = true

    // swipe (volume / brightness) state
    private var gestureMode = 0 // 0 = undecided, 1 = brightness, 2 = volume, -1 = ignore
    private var startBright = 0.5f
    private var startVol = 0
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }

    private val subLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }

    // resume protection: never overwrite a good saved position with ~0 while the start seek is settling
    private var resumeTarget = 0L
    private var resumeKey = ""
    private var resumeGuardUntil = 0L

    private val saver = object : Runnable {
        override fun run() {
            savePosition()
            handler.postDelayed(this, 3000)
        }
    }

    private val longPress = Runnable {
        speedActive = true
        prevSpeed = player.playbackParameters.speed
        player.setPlaybackSpeed(Prefs.holdSpeed)
        tvSpeed.text = "▶▶  ${Prefs.holdSpeed}x"
        tvSpeed.visibility = View.VISIBLE
        pv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private val hideSync = Runnable {
        syncPanel.visibility = View.GONE
        syncMode = -1
    }

    private val applySync = Runnable {
        if (::player.isInitialized) player.seekTo(player.currentPosition)
    }

    private val hideInfo = Runnable { tvInfo.visibility = View.GONE }

    private val hideSeek = Runnable {
        tvLeft.visibility = View.GONE
        tvRight.visibility = View.GONE
        acc = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        goFullscreen()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        pv = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvLeft = findViewById(R.id.tvLeft)
        tvRight = findViewById(R.id.tvRight)
        tvInfo = findViewById(R.id.tvInfo)
        syncPanel = findViewById(R.id.syncPanel)
        tvSyncTitle = findViewById(R.id.tvSyncTitle)
        tvSyncValue = findViewById(R.id.tvSyncValue)
        SyncState.subDelayMs = 0
        SyncState.audioDelayMs = 0

        val queue: List<Video>
        val start: Int
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) {
            queue = listOf(Video(0, data, displayName(data), 0, "", 0))
            start = 0
        } else {
            queue = PlaybackQueue.items
            start = PlaybackQueue.start
        }
        if (queue.isEmpty()) { finish(); return }

        val seekMs = Prefs.seekSeconds * 1000L
        player = ExoPlayer.Builder(this, SyncRenderersFactory(this))
            .setSeekBackIncrementMs(seekMs)
            .setSeekForwardIncrementMs(seekMs)
            .build()
        pv.player = player
        // Skipping is done only with double-tap; subtitle choice lives in the settings menu.
        pv.setShowRewindButton(false)
        pv.setShowFastForwardButton(false)
        pv.setShowSubtitleButton(false)
        pv.findViewById<View>(androidx.media3.ui.R.id.exo_settings)?.setOnClickListener { showSettingsMenu() }
        applySubtitleStyle()
        applyTimeBarColors()
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
            if (vis != View.VISIBLE) hideSync.run()
        })

        val items = queue.map {
            MediaItem.Builder().setUri(it.uri).setMediaId(it.uri.toString()).build()
        }
        val key = queue[start].uri.toString()
        val saved = Prefs.pos(key)
        val d = Prefs.dur(key)
        val startPos = if (Prefs.resume && saved > 3000 && (d <= 0 || saved < d - 8000)) saved else 0L
        resumeTarget = startPos
        resumeKey = key
        if (startPos > 0) resumeGuardUntil = SystemClock.elapsedRealtime() + 15000
        player.setMediaItems(items, start, startPos)
        player.setPauseAtEndOfMediaItems(!Prefs.autoNext)
        player.prepare()
        player.playWhenReady = true

        // some files ignore the start position; seek again once the player is ready
        if (startPos > 0) {
            player.addListener(object : androidx.media3.common.Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    if (state == androidx.media3.common.Player.STATE_READY) {
                        player.removeListener(this)
                        if (kotlin.math.abs(player.currentPosition - startPos) > 3000) {
                            player.seekTo(player.currentMediaItemIndex, startPos)
                        }
                    }
                }
            })
        }

        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (!isPlaying) savePosition()
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    val id = oldPosition.mediaItem?.mediaId ?: return
                    val dur = Prefs.dur(id)
                    if (dur > 0) Prefs.savePos(id, dur, dur)
                } else {
                    savePosition()
                }
            }
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSubSync).setOnClickListener { openSync(0) }
        findViewById<View>(R.id.btnAudioSync).setOnClickListener { openSync(1) }
        fun step(id: Int, d: Int) = findViewById<View>(id).setOnClickListener { setDelay(currentDelay() + d) }
        step(R.id.btnSyncM5, -500)
        step(R.id.btnSyncM1, -100)
        step(R.id.btnSyncP1, 100)
        step(R.id.btnSyncP5, 500)
        findViewById<View>(R.id.btnSyncReset).setOnClickListener { setDelay(0) }
        setupGestures()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        pv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y; moved = false
                    gestureMode = 0
                    startVol = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
                    startBright = currentBrightness()
                    if (e.x > v.width / 2f) handler.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (hypot(dx, dy) > slop) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                    if (moved && Prefs.swipe && !speedActive) {
                        if (gestureMode == 0) {
                            gestureMode = if (abs(dy) > abs(dx)) {
                                if (downX < v.width / 2f) 1 else 2
                            } else -1
                        }
                        if (gestureMode > 0) adjust(gestureMode, -dy / v.height)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) endSpeed()
                    else if (!moved) onTap(e.x > v.width / 2f)
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) endSpeed()
                }
            }
            true
        }
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        if (b >= 0f) return b
        return try {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        } catch (_: Exception) {
            0.5f
        }
    }

    private fun adjust(mode: Int, ratio: Float) {
        if (mode == 1) {
            val b = (startBright + ratio * 1.2f).coerceIn(0.02f, 1f)
            val lp = window.attributes
            lp.screenBrightness = b
            window.attributes = lp
            showInfo("🔆  " + Loc.digits(this, "${(b * 100).roundToInt()}%"))
        } else {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val vol = (startVol + ratio * max * 1.2f).roundToInt().coerceIn(0, max)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, vol, 0)
            val pct = if (max == 0) 0 else vol * 100 / max
            showInfo("🔊  " + Loc.digits(this, "$pct%"))
        }
    }

    private fun showInfo(text: String) {
        tvInfo.text = text
        tvInfo.visibility = View.VISIBLE
        handler.removeCallbacks(hideInfo)
        handler.postDelayed(hideInfo, 800)
    }

    private fun applySubtitleStyle() {
        val size = when (Prefs.subSize) {
            0 -> 0.045f
            2 -> 0.07f
            else -> 0.055f
        }
        val sv = pv.subtitleView ?: return
        sv.setFractionalTextSize(size)
        val style = if (Prefs.subBox) {
            CaptionStyleCompat(
                Color.WHITE, 0xB3000000.toInt(), Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_NONE, Color.BLACK, null
            )
        } else {
            CaptionStyleCompat(
                Color.WHITE, Color.TRANSPARENT, Color.TRANSPARENT,
                CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, null
            )
        }
        sv.setStyle(style)
    }

    private fun applyTimeBarColors() {
        val bar = pv.findViewById<View>(androidx.media3.ui.R.id.exo_progress) as? DefaultTimeBar ?: return
        val accent = themeColor(R.attr.appAccent)
        bar.setPlayedColor(accent)
        bar.setScrubberColor(accent)
        bar.setBufferedColor((accent and 0x00FFFFFF) or 0x66000000)
        bar.setUnplayedColor(0x33FFFFFF)
    }

    private fun endSpeed() {
        speedActive = false
        player.setPlaybackSpeed(prevSpeed)
        tvSpeed.visibility = View.GONE
    }

    private fun onTap(right: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (now - lastTapTime < 400) {
            pendingToggle?.let { handler.removeCallbacks(it) }
            pendingToggle = null
            doSeek(right)
        } else {
            val r = Runnable {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
            }
            pendingToggle = r
            handler.postDelayed(r, 400)
        }
        lastTapTime = now
    }

    private fun doSeek(forward: Boolean) {
        val s = Prefs.seekSeconds
        if (forward != accForward) acc = 0
        accForward = forward
        acc += s
        val dur = player.duration
        var t = player.currentPosition + (if (forward) s else -s) * 1000L
        t = t.coerceAtLeast(0L)
        if (dur != C.TIME_UNSET) t = t.coerceAtMost(dur)
        player.seekTo(t)

        val show = if (forward) tvRight else tvLeft
        val hide = if (forward) tvLeft else tvRight
        hide.visibility = View.GONE
        show.text = (if (forward) "+" else "−") + acc + " s"
        show.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeek)
        handler.postDelayed(hideSeek, 700)
    }

    private fun addSubtitle(uri: Uri) {
        val cur = player.currentMediaItem ?: return
        val name = displayName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .clearOverridesOfType(C.TRACK_TYPE_TEXT)
            .build()
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
    }

    // ---------- sync panel (subtitle / audio delay) ----------

    private fun currentDelay() = if (syncMode == 0) SyncState.subDelayMs else SyncState.audioDelayMs

    private fun openSync(mode: Int) {
        if (syncMode == mode && syncPanel.visibility == View.VISIBLE) {
            handler.removeCallbacks(hideSync)
            hideSync.run()
            return
        }
        syncMode = mode
        tvSyncTitle.setText(if (mode == 0) R.string.sync_subtitle else R.string.sync_audio)
        refreshSync()
        syncPanel.visibility = View.VISIBLE
        scheduleHideSync()
    }

    private fun scheduleHideSync() {
        handler.removeCallbacks(hideSync)
        handler.postDelayed(hideSync, 5000)
        pv.showController()
    }

    private fun setDelay(ms: Int) {
        val v = ms.coerceIn(-10000, 10000)
        if (syncMode == 0) SyncState.subDelayMs = v else SyncState.audioDelayMs = v
        refreshSync()
        scheduleHideSync()
        handler.removeCallbacks(applySync)
        handler.postDelayed(applySync, 300)
    }

    private fun refreshSync() {
        val v = currentDelay()
        val sign = if (v > 0) "+" else if (v < 0) "−" else ""
        val num = String.format(Locale.US, "%.1f", abs(v) / 1000f)
        tvSyncValue.text = Loc.digits(this, getString(R.string.sync_value, sign + num))
    }

    // ---------- settings menu ----------

    private fun showSettingsMenu() {
        val items: List<Pair<String, () -> Unit>> = listOf(
            getString(R.string.menu_speed) to { showSpeedMenu() },
            getString(R.string.menu_audio) to { showTrackMenu(C.TRACK_TYPE_AUDIO) },
            getString(R.string.menu_subtitle) to { showTrackMenu(C.TRACK_TYPE_TEXT) },
            getString(R.string.add_subtitle) to { subLauncher.launch(arrayOf("*/*")) }
        )
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.settings)
            .setItems(items.map { it.first }.toTypedArray()) { _, i -> items[i].second() }
            .show()
    }

    private fun showSpeedMenu() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = speeds.map { Loc.digits(this, "${it}x") }.toTypedArray()
        val cur = speeds.indexOfFirst { it == player.playbackParameters.speed }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.menu_speed)
            .setSingleChoiceItems(labels, cur) { d, i ->
                player.setPlaybackSpeed(speeds[i])
                d.dismiss()
            }
            .show()
    }

    private fun trackLabel(f: Format, n: Int): String {
        val lang = f.language?.takeIf { it != "und" }
            ?.let { Locale.forLanguageTag(it).displayLanguage }
            ?.takeIf { it.isNotBlank() }
        val parts = listOfNotNull(f.label, lang).distinct()
        return if (parts.isEmpty()) getString(R.string.track_n, n) else parts.joinToString(" · ")
    }

    private fun showTrackMenu(type: Int) {
        val isText = type == C.TRACK_TYPE_TEXT
        val entries = ArrayList<Triple<Tracks.Group, Int, String>>()
        for (g in player.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                if (!g.isTrackSupported(i)) continue
                entries.add(Triple(g, i, trackLabel(g.getTrackFormat(i), entries.size + 1)))
            }
        }
        if (entries.isEmpty()) {
            Toast.makeText(this, R.string.no_tracks, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ArrayList<String>()
        if (isText) labels.add(getString(R.string.sub_off))
        entries.forEach { labels.add(it.third) }
        val shift = if (isText) 1 else 0
        var checked = -1
        if (isText && player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)) {
            checked = 0
        } else {
            entries.forEachIndexed { idx, e -> if (e.first.isTrackSelected(e.second)) checked = idx + shift }
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(if (isText) R.string.menu_subtitle else R.string.menu_audio)
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val b = player.trackSelectionParameters.buildUpon()
                if (isText && which == 0) {
                    b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                } else {
                    val e = entries[which - shift]
                    b.setTrackTypeDisabled(type, false)
                        .setOverrideForType(TrackSelectionOverride(e.first.mediaTrackGroup, e.second))
                }
                player.trackSelectionParameters = b.build()
                d.dismiss()
            }
            .show()
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "video"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) name = c.getString(i)
            }
        } catch (_: Exception) {
        }
        return name
    }

    private fun savePosition() {
        if (!::player.isInitialized) return
        val item = player.currentMediaItem ?: return
        val d = player.duration
        val pos = player.currentPosition
        if (resumeTarget > 0 && SystemClock.elapsedRealtime() < resumeGuardUntil &&
            item.mediaId == resumeKey && pos < resumeTarget - 3000
        ) return
        if (d != C.TIME_UNSET && d > 0) {
            Prefs.savePos(item.mediaId, pos, d)
            Prefs.lastKey = item.mediaId
        }
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStart() {
        super.onStart()
        handler.post(saver)
    }

    override fun onPause() {
        super.onPause()
        savePosition()
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saver)
        savePosition()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (::player.isInitialized) player.release()
    }
}
