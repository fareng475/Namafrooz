package com.namafrooz.player

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.hypot

@UnstableApi
class PlayerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var pv: PlayerView
    private lateinit var topBar: View
    private lateinit var tvSpeed: TextView
    private lateinit var tvLeft: TextView
    private lateinit var tvRight: TextView

    private val handler = Handler(Looper.getMainLooper())

    // gesture state
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var speedActive = false
    private var prevSpeed = 1f
    private var lastTapTime = 0L
    private var pendingToggle: Runnable? = null
    private var acc = 0
    private var accForward = true

    private val subLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addSubtitle(uri)
    }

    private val saver = object : Runnable {
        override fun run() {
            savePosition()
            handler.postDelayed(this, 3000)
        }
    }

    private val longPress = Runnable {
        speedActive = true
        prevSpeed = player.playbackParameters.speed
        player.setPlaybackSpeed(Prefs.holdSpeed)
        tvSpeed.text = "▶▶  ${Prefs.holdSpeed}x"
        tvSpeed.visibility = View.VISIBLE
        pv.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private val hideSeek = Runnable {
        tvLeft.visibility = View.GONE
        tvRight.visibility = View.GONE
        acc = 0
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        setContentView(R.layout.activity_player)
        goFullscreen()

        pv = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        tvSpeed = findViewById(R.id.tvSpeed)
        tvLeft = findViewById(R.id.tvLeft)
        tvRight = findViewById(R.id.tvRight)

        val queue: List<Video>
        val start: Int
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) {
            queue = listOf(Video(0, data, displayName(data), 0, "", 0))
            start = 0
        } else {
            queue = PlaybackQueue.items
            start = PlaybackQueue.start
        }
        if (queue.isEmpty()) { finish(); return }

        val seekMs = Prefs.seekSeconds * 1000L
        player = ExoPlayer.Builder(this)
            .setSeekBackIncrementMs(seekMs)
            .setSeekForwardIncrementMs(seekMs)
            .build()
        pv.player = player
        pv.subtitleView?.setFractionalTextSize(0.055f)
        pv.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })

        val items = queue.map {
            MediaItem.Builder().setUri(it.uri).setMediaId(it.uri.toString()).build()
        }
        val key = queue[start].uri.toString()
        val saved = Prefs.pos(key)
        val d = Prefs.dur(key)
        val startPos = if (Prefs.resume && saved > 5000 && d > 0 && saved < d * 0.95) saved else 0L
        player.setMediaItems(items, start, startPos)
        player.prepare()
        player.playWhenReady = true

        player.addListener(object : androidx.media3.common.Player.Listener {
            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    val id = oldPosition.mediaItem?.mediaId ?: return
                    val dur = Prefs.dur(id)
                    if (dur > 0) Prefs.savePos(id, dur, dur)
                }
            }
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSub).setOnClickListener { subLauncher.launch(arrayOf("*/*")) }
        setupGestures()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        pv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x; downY = e.y; moved = false
                    if (e.x > v.width / 2f) handler.postDelayed(longPress, 350)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (hypot(e.x - downX, e.y - downY) > slop) {
                        moved = true
                        handler.removeCallbacks(longPress)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) endSpeed()
                    else if (!moved) onTap(e.x > v.width / 2f)
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    if (speedActive) endSpeed()
                }
            }
            true
        }
    }

    private fun endSpeed() {
        speedActive = false
        player.setPlaybackSpeed(prevSpeed)
        tvSpeed.visibility = View.GONE
    }

    private fun onTap(right: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (now - lastTapTime < 400) {
            pendingToggle?.let { handler.removeCallbacks(it) }
            pendingToggle = null
            doSeek(right)
        } else {
            val r = Runnable {
                if (pv.isControllerFullyVisible) pv.hideController() else pv.showController()
            }
            pendingToggle = r
            handler.postDelayed(r, 400)
        }
        lastTapTime = now
    }

    private fun doSeek(forward: Boolean) {
        val s = Prefs.seekSeconds
        if (forward != accForward) acc = 0
        accForward = forward
        acc += s
        val dur = player.duration
        var t = player.currentPosition + (if (forward) s else -s) * 1000L
        t = t.coerceAtLeast(0L)
        if (dur != C.TIME_UNSET) t = t.coerceAtMost(dur)
        player.seekTo(t)

        val show = if (forward) tvRight else tvLeft
        val hide = if (forward) tvLeft else tvRight
        hide.visibility = View.GONE
        show.text = (if (forward) "+" else "−") + acc + " s"
        show.visibility = View.VISIBLE
        handler.removeCallbacks(hideSeek)
        handler.postDelayed(hideSeek, 700)
    }

    private fun addSubtitle(uri: Uri) {
        val cur = player.currentMediaItem ?: return
        val name = displayName(uri).lowercase()
        val mime = when {
            name.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            name.endsWith(".ass") || name.endsWith(".ssa") -> MimeTypes.TEXT_SSA
            name.endsWith(".ttml") || name.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val sub = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val idx = player.currentMediaItemIndex
        val pos = player.currentPosition
        player.replaceMediaItem(idx, cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build())
        player.seekTo(idx, pos)
    }

    private fun displayName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "video"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) name = c.getString(i)
            }
        } catch (_: Exception) {
        }
        return name
    }

    private fun savePosition() {
        if (!::player.isInitialized) return
        val item = player.currentMediaItem ?: return
        val d = player.duration
        if (d != C.TIME_UNSET && d > 0) Prefs.savePos(item.mediaId, player.currentPosition, d)
    }

    private fun goFullscreen() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    override fun onStart() {
        super.onStart()
        handler.post(saver)
    }

    override fun onStop() {
        super.onStop()
        handler.removeCallbacks(saver)
        savePosition()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
        if (::player.isInitialized) player.release()
    }
}
