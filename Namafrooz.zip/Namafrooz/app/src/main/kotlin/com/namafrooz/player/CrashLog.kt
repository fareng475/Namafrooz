package com.namafrooz.player

import android.content.Context
import android.os.Build
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps a small text file of crashes and handled errors so they can be copied from the settings. */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "error_log.txt")

    fun install(app: Context) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                add(app, "CRASH in thread " + t.name, e)
            } catch (_: Throwable) {
            }
            previous?.uncaughtException(t, e)
        }
    }

    fun add(ctx: Context, title: String, e: Throwable? = null) {
        try {
            val f = file(ctx)
            if (f.exists() && f.length() > 200_000) f.delete()
            val version = try {
                ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "?"
            } catch (_: Exception) {
                "?"
            }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val sb = StringBuilder()
            sb.append("[").append(time).append("] ").append(title).append('\n')
            sb.append("app ").append(version).append(" | ").append(Build.MANUFACTURER).append(' ')
                .append(Build.MODEL).append(" | Android ").append(Build.VERSION.SDK_INT).append('\n')
            if (e != null) {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                sb.append(sw.toString().take(4000)).append('\n')
            }
            sb.append("----------------------------------------\n")
            f.appendText(sb.toString())
        } catch (_: Throwable) {
        }
    }

    fun read(ctx: Context): String = try {
        val f = file(ctx)
        if (f.exists()) f.readText() else ""
    } catch (_: Throwable) {
        ""
    }

    fun clear(ctx: Context) {
        try {
            file(ctx).delete()
        } catch (_: Throwable) {
        }
    }
}
